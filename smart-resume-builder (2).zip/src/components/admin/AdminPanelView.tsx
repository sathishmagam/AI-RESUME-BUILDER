import React, { useState } from 'react';
import { Shield, Users, FileText, Download, Trash2, Search, CheckCircle, BarChart3, MessageSquare } from 'lucide-react';

export const AdminPanelView: React.FC = () => {
  const [usersList, setUsersList] = useState([
    { id: 'usr_1', name: 'Alex Morgan', email: 'alex.morgan@example.com', role: 'user', resumesCount: 2, status: 'Active', joined: '2026-01-15' },
    { id: 'usr_2', name: 'Sarah Jenkins', email: 'sarah.j@example.com', role: 'user', resumesCount: 3, status: 'Active', joined: '2026-02-01' },
    { id: 'usr_3', name: 'David Chen', email: 'd.chen@example.com', role: 'user', resumesCount: 1, status: 'Active', joined: '2026-03-10' },
    { id: 'usr_4', name: 'Emily Taylor', email: 'emily.t@example.com', role: 'user', resumesCount: 4, status: 'Active', joined: '2026-04-12' },
  ]);

  const [searchUser, setSearchUser] = useState('');

  const toggleUserStatus = (id: string) => {
    setUsersList(usersList.map(u => (u.id === id ? { ...u, status: u.status === 'Active' ? 'Blocked' : 'Active' } : u)));
  };

  const deleteUser = (id: string) => {
    setUsersList(usersList.filter(u => u.id !== id));
  };

  const filteredUsers = usersList.filter(u =>
    u.name.toLowerCase().includes(searchUser.toLowerCase()) ||
    u.email.toLowerCase().includes(searchUser.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-8 shadow-xl flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 text-xs font-bold mb-2">
            <Shield className="w-3.5 h-3.5 text-purple-400" /> Platform Admin Portal
          </div>
          <h1 className="text-3xl font-extrabold tracking-tight">System Dashboard & Analytics</h1>
          <p className="text-xs text-slate-400 mt-1">Manage user accounts, templates, platform metrics, and feedback</p>
        </div>
      </div>

      {/* Analytics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
        <div className="p-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-500 font-bold">Total Users</span>
            <Users className="w-4 h-4 text-blue-500" />
          </div>
          <span className="text-2xl font-black text-slate-900 dark:text-white">{usersList.length + 120}</span>
          <span className="text-[10px] text-emerald-600 font-semibold block mt-1">+12% this month</span>
        </div>

        <div className="p-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-500 font-bold">Resumes Created</span>
            <FileText className="w-4 h-4 text-purple-500" />
          </div>
          <span className="text-2xl font-black text-slate-900 dark:text-white">1,480</span>
          <span className="text-[10px] text-emerald-600 font-semibold block mt-1">+24% growth</span>
        </div>

        <div className="p-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-500 font-bold">PDF Downloads</span>
            <Download className="w-4 h-4 text-emerald-500" />
          </div>
          <span className="text-2xl font-black text-slate-900 dark:text-white">3,920</span>
          <span className="text-[10px] text-emerald-600 font-semibold block mt-1">100% Vector PDF</span>
        </div>

        <div className="p-5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-500 font-bold">Avg ATS Score</span>
            <BarChart3 className="w-4 h-4 text-amber-500" />
          </div>
          <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">89.4%</span>
          <span className="text-[10px] text-slate-400 block mt-1">High recruiter pass rate</span>
        </div>
      </div>

      {/* User Management Section */}
      <div className="bg-white dark:bg-slate-800 rounded-3xl border border-slate-200 dark:border-slate-700 p-6 space-y-4 text-xs">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pb-4 border-b border-slate-100 dark:border-slate-700">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">User Accounts Manager</h2>
            <p className="text-slate-400 text-xs">Manage active user accounts and permissions</p>
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchUser}
              onChange={e => setSearchUser(e.target.value)}
              placeholder="Search user by name or email..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-400 text-[11px] uppercase font-bold">
                <th className="pb-3 px-2">User Name</th>
                <th className="pb-3 px-2">Email</th>
                <th className="pb-3 px-2">Resumes</th>
                <th className="pb-3 px-2">Joined Date</th>
                <th className="pb-3 px-2">Status</th>
                <th className="pb-3 px-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-700 text-slate-700 dark:text-slate-300">
              {filteredUsers.map(user => (
                <tr key={user.id} className="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition-colors">
                  <td className="py-3 px-2 font-bold text-slate-900 dark:text-white">{user.name}</td>
                  <td className="py-3 px-2 text-slate-500">{user.email}</td>
                  <td className="py-3 px-2 font-mono">{user.resumesCount}</td>
                  <td className="py-3 px-2">{user.joined}</td>
                  <td className="py-3 px-2">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        user.status === 'Active' ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200' : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {user.status}
                    </span>
                  </td>
                  <td className="py-3 px-2 text-right space-x-2">
                    <button
                      onClick={() => toggleUserStatus(user.id)}
                      className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 text-slate-800 dark:text-slate-200 font-semibold"
                    >
                      {user.status === 'Active' ? 'Block' : 'Unblock'}
                    </button>
                    <button
                      onClick={() => deleteUser(user.id)}
                      className="p-1 rounded text-red-500 hover:bg-red-50"
                      title="Delete User"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

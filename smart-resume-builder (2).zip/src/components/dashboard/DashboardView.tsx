import React, { useState } from 'react';
import { ResumeData } from '../../types/resume';
import { SAMPLE_RESUMES } from '../../data/initialData';
import {
  FileText,
  Plus,
  Search,
  Edit,
  Copy,
  Trash2,
  Download,
  Sparkles,
  Star,
  Clock,
  Layout,
  Share2,
  CheckCircle
} from 'lucide-react';

interface DashboardViewProps {
  resumes: ResumeData[];
  onCreateNew: () => void;
  onEditResume: (resume: ResumeData) => void;
  onDuplicateResume: (resume: ResumeData) => void;
  onDeleteResume: (id: string) => void;
  onSelectPrimary: (id: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  resumes,
  onCreateNew,
  onEditResume,
  onDuplicateResume,
  onDeleteResume,
  onSelectPrimary,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTemplate, setFilterTemplate] = useState('all');

  const filteredResumes = resumes.filter(r => {
    const matchesSearch = r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.personalInfo.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.personalInfo.jobTitle.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesTemplate = filterTemplate === 'all' || r.style.template === filterTemplate;
    return matchesSearch && matchesTemplate;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-200 block mb-1">
            Welcome Back!
          </span>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            My Resumes & Drafts
          </h1>
          <p className="text-xs text-blue-100 mt-1 max-w-xl">
            Manage your professional resumes, run ATS keyword audits, and download tailored PDF versions anytime.
          </p>
        </div>

        <button
          onClick={onCreateNew}
          className="px-6 py-3 rounded-xl bg-white text-blue-700 hover:bg-blue-50 font-extrabold text-xs flex items-center gap-2 shadow-lg transition-transform active:scale-95 shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Resume</span>
        </button>
      </div>

      {/* Stats Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
        <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-slate-400 font-medium block">Total Resumes</span>
          <span className="text-2xl font-extrabold text-slate-900 dark:text-white mt-1 block">
            {resumes.length}
          </span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-slate-400 font-medium block">Average ATS Score</span>
          <span className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 mt-1 block">
            {Math.round(resumes.reduce((acc, curr) => acc + (curr.atsScore || 85), 0) / (resumes.length || 1))}%
          </span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-slate-400 font-medium block">Primary Resume</span>
          <span className="text-sm font-bold text-blue-600 dark:text-blue-400 mt-2 block truncate">
            {resumes.find(r => r.isPrimary)?.title || 'None Selected'}
          </span>
        </div>

        <div className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs">
          <span className="text-slate-400 font-medium block">AI Optimization</span>
          <span className="text-sm font-bold text-purple-600 dark:text-purple-400 mt-2 block">
            ✨ Active Ready
          </span>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4 bg-white dark:bg-slate-800 p-4 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs text-xs">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search resumes by title or job role..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <label className="text-slate-500 font-medium">Filter Template:</label>
          <select
            value={filterTemplate}
            onChange={e => setFilterTemplate(e.target.value)}
            className="px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white font-semibold"
          >
            <option value="all">All Templates</option>
            <option value="modern">Modern</option>
            <option value="classic">Classic</option>
            <option value="executive">Executive</option>
            <option value="minimal">Minimal</option>
            <option value="creative">Creative</option>
            <option value="tech">Tech Minimalist</option>
          </select>
        </div>
      </div>

      {/* Resumes Collection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Create New Card */}
        <div
          onClick={onCreateNew}
          className="group p-8 rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 bg-slate-50/50 dark:bg-slate-800/50 flex flex-col items-center justify-center text-center cursor-pointer transition-all hover:scale-102 min-h-[220px]"
        >
          <div className="w-12 h-12 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-600 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
            <Plus className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">Create New Resume</h3>
          <p className="text-xs text-slate-500 mt-1">Start from a blank canvas or sample data</p>
        </div>

        {/* Saved Resume Cards */}
        {filteredResumes.map(resume => (
          <div
            key={resume.id}
            className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-5 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white line-clamp-1">{resume.title}</h3>
                  <p className="text-xs text-blue-600 dark:text-blue-400 font-semibold">{resume.personalInfo.jobTitle}</p>
                </div>

                {resume.isPrimary ? (
                  <span className="px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-[10px] font-bold flex items-center gap-1">
                    <Star className="w-3 h-3 fill-blue-600" /> Primary
                  </span>
                ) : (
                  <button
                    onClick={() => onSelectPrimary(resume.id)}
                    className="text-[10px] text-slate-400 hover:text-blue-600 font-semibold"
                  >
                    Set Primary
                  </button>
                )}
              </div>

              <div className="flex items-center gap-2 text-[11px] text-slate-500 my-3">
                <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-700 font-semibold uppercase text-[10px]">
                  {resume.style.template}
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-400" />
                  {new Date(resume.updatedAt).toLocaleDateString()}
                </span>
                <span>•</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                  ATS {resume.atsScore || 88}%
                </span>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 italic">
                "{resume.personalInfo.summary || 'No summary provided yet...'}"
              </p>
            </div>

            {/* Card Footer Actions */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between text-xs font-semibold">
              <button
                onClick={() => onEditResume(resume)}
                className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-1 shadow-2xs"
              >
                <Edit className="w-3.5 h-3.5" /> Edit
              </button>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => onDuplicateResume(resume)}
                  className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300"
                  title="Duplicate Resume"
                >
                  <Copy className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onDeleteResume(resume.id)}
                  className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/50 text-red-500"
                  title="Delete Resume"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

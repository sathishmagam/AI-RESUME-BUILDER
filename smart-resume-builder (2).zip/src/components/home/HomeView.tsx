import React, { useState } from 'react';
import { TEMPLATE_METADATA } from '../../data/initialData';
import { generateAiSummary, enhanceAiBullet } from '../../services/aiService';
import {
  Sparkles,
  ArrowRight,
  CheckCircle2,
  FileCheck2,
  Download,
  Zap,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Star,
  Users,
  Briefcase,
  Layers,
  Send
} from 'lucide-react';

interface HomeViewProps {
  onStartBuilding: () => void;
  onExploreTemplates: () => void;
  onNavigate: (view: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onStartBuilding,
  onExploreTemplates,
  onNavigate,
}) => {
  // Hero Interactive AI Sandbox
  const [heroJobTitle, setHeroJobTitle] = useState('Software Engineer');
  const [heroWeakBullet, setHeroWeakBullet] = useState('Worked on web app features and fixed bugs.');
  const [heroEnhanced, setHeroEnhanced] = useState<string[]>([]);
  const [isEnhancingHero, setIsEnhancingHero] = useState(false);

  // FAQ State
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  // Contact Form
  const [contactSubmitted, setContactSubmitted] = useState(false);

  const handleTestHeroAi = async () => {
    setIsEnhancingHero(true);
    try {
      const results = await enhanceAiBullet(heroJobTitle, heroWeakBullet);
      setHeroEnhanced(results);
    } catch (err) {
      console.error(err);
    } finally {
      setIsEnhancingHero(false);
    }
  };

  const FAQS = [
    {
      q: 'Is Smart Resume Builder completely free to use?',
      a: 'Yes! You can create, customize, and download your high-resolution vector PDF resume without watermarks or hidden charges.',
    },
    {
      q: 'How does the ATS Score checker work?',
      a: 'Our ATS scanner compares your resume text against target job descriptions using NLP keyword matching and section analysis to ensure your resume passes recruiter screeners.',
    },
    {
      q: 'Can I export my resume as a PDF?',
      a: 'Absolutely. We use native vector browser print rendering to ensure sharp fonts, zero blurriness, and exact page dimensions.',
    },
    {
      q: 'What is the AI Bullet Point Enhancer?',
      a: 'Powered by Gemini AI, it analyzes weak job experience descriptions and transforms them into quantified, impact-driven statements with action verbs.',
    },
  ];

  return (
    <div className="space-y-20 pb-16">
      {/* Hero Section */}
      <section className="relative pt-12 pb-16 md:pt-20 md:pb-24 overflow-hidden bg-gradient-to-b from-blue-50/80 via-white to-slate-50 dark:from-slate-900 dark:via-slate-900 dark:to-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Content */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 text-xs font-bold shadow-2xs border border-blue-200 dark:border-blue-800">
                <Sparkles className="w-3.5 h-3.5 text-blue-600 animate-spin" />
                <span>Next-Gen AI Resume Engine v2.5</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 dark:text-white tracking-tight leading-none">
                Build an <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">ATS-Beating</span> Resume in Minutes.
              </h1>

              <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
                Craft professional, high-impact resumes tailored to your dream job. Use Gemini AI to optimize bullet points, calculate ATS scores, and stand out to recruiters.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
                <button
                  onClick={onStartBuilding}
                  className="px-8 py-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-extrabold text-sm flex items-center gap-2 shadow-xl shadow-blue-600/30 transition-all hover:scale-102 active:scale-98"
                >
                  <span>Build Resume Now</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onExploreTemplates}
                  className="px-6 py-4 rounded-xl bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 font-bold text-sm border border-slate-200 dark:border-slate-700 shadow-sm transition-all"
                >
                  View Templates
                </button>
              </div>

              {/* Trust Badges */}
              <div className="pt-6 border-t border-slate-200 dark:border-slate-800 flex flex-wrap justify-center lg:justify-start gap-6 text-xs text-slate-500 dark:text-slate-400 font-medium">
                <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-emerald-500" /> 100% Free Export</span>
                <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-emerald-500" /> ATS Approved Templates</span>
                <span className="flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-emerald-500" /> No Registration Required</span>
              </div>
            </div>

            {/* Right Interactive AI Test Drive Widget */}
            <div className="lg:col-span-5 bg-white dark:bg-slate-800 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-700 p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-950 flex items-center justify-center text-purple-600">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-xs text-slate-900 dark:text-white">Try AI Bullet Enhancer</h3>
                    <p className="text-[10px] text-slate-400">Interactive live demo</p>
                  </div>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300">
                  Live Preview
                </span>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Target Job Title</label>
                  <input
                    type="text"
                    value={heroJobTitle}
                    onChange={e => setHeroJobTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Enter a Weak Experience Bullet</label>
                  <input
                    type="text"
                    value={heroWeakBullet}
                    onChange={e => setHeroWeakBullet(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>

                <button
                  onClick={handleTestHeroAi}
                  disabled={isEnhancingHero}
                  className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-md transition-all"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  {isEnhancingHero ? 'Optimizing with Gemini AI...' : 'Generate High-Impact Bullet'}
                </button>

                {heroEnhanced.length > 0 && (
                  <div className="p-3 bg-purple-50 dark:bg-purple-950/40 rounded-xl border border-purple-200 dark:border-purple-800 space-y-1.5">
                    <span className="font-bold text-purple-900 dark:text-purple-200 text-[11px] block">
                      ✨ AI Quantified Result:
                    </span>
                    <p className="text-slate-800 dark:text-slate-200 text-xs bg-white dark:bg-slate-900 p-2 rounded border border-purple-100 dark:border-purple-900">
                      {heroEnhanced[0]}
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Everything You Need to Land Your Next Job
          </h2>
          <p className="text-slate-600 dark:text-slate-400 text-sm mt-2">
            Powerful tools designed specifically for students, freshers, job seekers, and senior professionals.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              icon: Sparkles,
              title: 'AI Resume Optimization',
              desc: 'Automatically improve professional summaries, rewrite experience bullet points with action verbs, and suggest skills tailored to your role.',
              color: 'text-purple-600 bg-purple-50 dark:bg-purple-950/50',
            },
            {
              icon: FileCheck2,
              title: 'ATS Resume Score Audit',
              desc: 'Scan your resume against real job postings. Get keyword density scores, missing critical term alerts, and formatting compliance checks.',
              color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/50',
            },
            {
              icon: Layers,
              title: 'Multiple Professional Templates',
              desc: 'Choose from Classic, Modern, Executive, Scandinavian Minimal, Creative, and Tech Minimalist styles designed by recruitment experts.',
              color: 'text-blue-600 bg-blue-50 dark:bg-blue-950/50',
            },
            {
              icon: Download,
              title: 'High-Fidelity PDF Download',
              desc: 'Export 100% crisp, print-ready PDF files with single-page layout alignment, customizable font sizes, and color palettes.',
              color: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950/50',
            },
            {
              icon: Zap,
              title: 'Real-Time Live Preview',
              desc: 'See instant changes as you type. Adjust font styles, primary colors, zoom levels, and reorder sections effortlessly.',
              color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/50',
            },
            {
              icon: ShieldCheck,
              title: 'Privacy & Data Control',
              desc: 'Your data belongs to you. Save drafts locally, export JSON backups, or share viewable links whenever you choose.',
              color: 'text-teal-600 bg-teal-50 dark:bg-teal-950/50',
            },
          ].map((feat, idx) => {
            const IconComponent = feat.icon;
            return (
              <div
                key={idx}
                className="p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xs hover:shadow-md transition-shadow space-y-3"
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold ${feat.color}`}>
                  <IconComponent className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">{feat.title}</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">{feat.desc}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Templates Gallery Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 shadow-2xl">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-10 gap-4">
            <div>
              <span className="text-xs font-bold text-blue-400 uppercase tracking-widest block mb-1">
                Handcrafted Layouts
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight">Explore Professional Templates</h2>
            </div>
            <button
              onClick={onExploreTemplates}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-2 transition-colors"
            >
              <span>View All 6 Templates</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {TEMPLATE_METADATA.slice(0, 3).map(tm => (
              <div
                key={tm.id}
                onClick={onStartBuilding}
                className="group bg-slate-800 rounded-2xl p-5 border border-slate-700 hover:border-blue-500 cursor-pointer transition-all hover:-translate-y-1"
              >
                <div className={`h-40 rounded-xl mb-4 ${tm.thumbnailColor} flex items-center justify-center text-white font-bold text-lg shadow-inner`}>
                  {tm.name}
                </div>
                <div className="flex justify-between items-center mb-1">
                  <h3 className="font-bold text-sm text-white">{tm.name}</h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300">
                    {tm.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-400">{tm.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works (4 Easy Steps) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-2">
          How It Works
        </h2>
        <p className="text-slate-600 dark:text-slate-400 text-sm max-w-xl mx-auto mb-12">
          Create a job-ready resume in 4 simple steps.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-6 text-left">
          {[
            { step: '01', title: 'Enter Details', desc: 'Fill in your personal info, experience, education, projects, and skills.' },
            { step: '02', title: 'AI Enhance', desc: 'Use Gemini AI to polish your summary, quantify bullet points, and check grammar.' },
            { step: '03', title: 'Select Template', desc: 'Pick your preferred template, customize primary colors, fonts, and section orders.' },
            { step: '04', title: 'Download PDF', desc: 'Export high-definition PDF files or print directly for job applications.' },
          ].map((st, i) => (
            <div key={i} className="p-6 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xs">
              <span className="text-3xl font-black text-blue-600 dark:text-blue-400 block mb-2">{st.step}</span>
              <h3 className="font-bold text-base text-slate-900 dark:text-white mb-1">{st.title}</h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">{st.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ Accordion */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="space-y-3">
          {FAQS.map((faq, idx) => (
            <div
              key={idx}
              onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
              className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 p-4 cursor-pointer transition-colors"
            >
              <div className="flex justify-between items-center font-bold text-sm text-slate-900 dark:text-white">
                <span>{faq.q}</span>
                {openFaq === idx ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
              </div>
              {openFaq === idx && (
                <p className="mt-3 text-xs text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-700 pt-3">
                  {faq.a}
                </p>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Contact Section */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-3xl p-8 sm:p-10 shadow-xl space-y-4">
          <h2 className="text-2xl font-bold tracking-tight">Have Questions or Feature Requests?</h2>
          <p className="text-xs text-slate-300">We love hearing from students and job seekers. Send us a message!</p>

          {contactSubmitted ? (
            <div className="p-4 bg-emerald-500/20 border border-emerald-400/40 rounded-xl text-emerald-200 text-xs font-bold flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              Thank you! Your message has been received. We will get back to you shortly.
            </div>
          ) : (
            <form
              onSubmit={e => {
                e.preventDefault();
                setContactSubmitted(true);
              }}
              className="space-y-3 text-xs"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Your Name"
                  className="px-4 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
                <input
                  type="email"
                  required
                  placeholder="Your Email"
                  className="px-4 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
              </div>
              <textarea
                required
                rows={3}
                placeholder="How can we help you?"
                className="w-full px-4 py-2.5 rounded-xl bg-white/10 border border-white/20 text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400"
              />
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold flex items-center gap-2 shadow-md"
              >
                <Send className="w-4 h-4" /> Send Message
              </button>
            </form>
          )}
        </div>
      </section>
    </div>
  );
};

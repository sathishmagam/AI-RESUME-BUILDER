import React, { useState } from 'react';
import { ResumeData } from '../../types/resume';
import {
  downloadAsPdf,
  downloadAsWordDoc,
  downloadAsPlainText,
  downloadAsJson,
} from '../../utils/documentExporter';
import {
  FileText,
  FileCode,
  FileSpreadsheet,
  Download,
  X,
  CheckCircle2,
  Printer,
  Sparkles,
  FileDown,
  Loader2,
  AlertCircle,
} from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  data: ResumeData;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose, data }) => {
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleAction = async (type: 'pdf' | 'doc' | 'txt' | 'json') => {
    setIsGenerating(true);
    setErrorMsg(null);
    setDownloadSuccess(null);

    try {
      console.log(`[DownloadModal] Triggering ${type.toUpperCase()} export for "${data?.personalInfo?.fullName}"...`);

      switch (type) {
        case 'pdf': {
          const res = await downloadAsPdf(data, 'printable-resume');
          if (res.method === 'jsPDF') {
            setDownloadSuccess('PDF Document downloaded successfully!');
          } else {
            setDownloadSuccess('Browser PDF Print window opened!');
          }
          break;
        }
        case 'doc': {
          downloadAsWordDoc(data);
          setDownloadSuccess('Microsoft Word (.doc) downloaded successfully!');
          break;
        }
        case 'txt': {
          downloadAsPlainText(data);
          setDownloadSuccess('Plain Text (.txt) downloaded successfully!');
          break;
        }
        case 'json': {
          downloadAsJson(data);
          setDownloadSuccess('JSON Backup file downloaded!');
          break;
        }
      }
    } catch (err: any) {
      console.error('[DownloadModal] Document export error:', err);
      setErrorMsg(err?.message || 'An error occurred during document generation. Please try again.');
    } finally {
      setIsGenerating(false);
      setTimeout(() => {
        setDownloadSuccess(null);
      }, 4000);
    }
  };

  const documentName = data?.personalInfo?.fullName
    ? `${data.personalInfo.fullName}'s Resume`
    : data?.title || 'Resume Document';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-700 text-white flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-white/10 rounded-xl backdrop-blur-md">
              <FileDown className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold">Download Document</h2>
              <p className="text-xs text-blue-100">Export "{documentName}" in your preferred format</p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isGenerating}
            className="p-1.5 rounded-lg hover:bg-white/20 text-white transition-colors disabled:opacity-50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Banner */}
        {downloadSuccess && (
          <div className="bg-emerald-50 dark:bg-emerald-950/50 border-b border-emerald-200 dark:border-emerald-800 px-4 py-2.5 flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-300">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>{downloadSuccess}</span>
          </div>
        )}

        {/* Error Banner */}
        {errorMsg && (
          <div className="bg-red-50 dark:bg-red-950/50 border-b border-red-200 dark:border-red-800 px-4 py-2.5 flex items-center gap-2 text-xs font-semibold text-red-800 dark:text-red-300">
            <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Download Format Options Grid */}
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            
            {/* Option 1: PDF */}
            <div
              onClick={() => !isGenerating && handleAction('pdf')}
              className={`p-4 rounded-xl border-2 transition-all cursor-pointer group flex flex-col justify-between ${
                isGenerating
                  ? 'opacity-60 cursor-not-allowed border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800'
                  : 'border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 bg-slate-50/50 dark:bg-slate-800/50 hover:bg-blue-50/50 dark:hover:bg-blue-950/30'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-red-100 dark:bg-red-900/40 text-red-600 dark:text-red-400">
                      <Printer className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-900 dark:text-white">PDF Document</span>
                  </div>
                  <span className="text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
                    Recommended
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  High-resolution vector PDF containing all formatting, exact colors, fonts, and multi-page layout.
                </p>
              </div>
              <div className="mt-3 pt-2 flex items-center justify-between text-xs font-bold text-blue-600 dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>{isGenerating ? 'Generating PDF...' : 'Export PDF'}</span>
                {isGenerating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              </div>
            </div>

            {/* Option 2: Word (.doc) */}
            <div
              onClick={() => !isGenerating && handleAction('doc')}
              className={`p-4 rounded-xl border-2 transition-all cursor-pointer group flex flex-col justify-between ${
                isGenerating
                  ? 'opacity-60 cursor-not-allowed border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800'
                  : 'border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 bg-slate-50/50 dark:bg-slate-800/50 hover:bg-blue-50/50 dark:hover:bg-blue-950/30'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400">
                      <FileText className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-900 dark:text-white">Word Document (.doc)</span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                    Editable
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  Formatted Microsoft Word document with headers, bullets, and tables. Fully editable in MS Word & Google Docs.
                </p>
              </div>
              <div className="mt-3 pt-2 flex items-center justify-between text-xs font-bold text-blue-600 dark:text-blue-400 group-hover:translate-x-1 transition-transform">
                <span>Export Word Doc</span>
                <Download className="w-4 h-4" />
              </div>
            </div>

            {/* Option 3: Plain Text (.txt) */}
            <div
              onClick={() => !isGenerating && handleAction('txt')}
              className={`p-4 rounded-xl border-2 transition-all cursor-pointer group flex flex-col justify-between ${
                isGenerating
                  ? 'opacity-60 cursor-not-allowed border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800'
                  : 'border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 bg-slate-50/50 dark:bg-slate-800/50 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/30'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400">
                      <FileSpreadsheet className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-900 dark:text-white">Plain Text (.txt)</span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300">
                    ATS Portal Friendly
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  Clean, structured plain text formatted with standard section titles. Perfect for web forms and ATS copy-paste.
                </p>
              </div>
              <div className="mt-3 pt-2 flex items-center justify-between text-xs font-bold text-emerald-600 dark:text-emerald-400 group-hover:translate-x-1 transition-transform">
                <span>Export Text File</span>
                <Download className="w-4 h-4" />
              </div>
            </div>

            {/* Option 4: JSON Backup */}
            <div
              onClick={() => !isGenerating && handleAction('json')}
              className={`p-4 rounded-xl border-2 transition-all cursor-pointer group flex flex-col justify-between ${
                isGenerating
                  ? 'opacity-60 cursor-not-allowed border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800'
                  : 'border-slate-200 dark:border-slate-800 hover:border-purple-500 dark:hover:border-purple-500 bg-slate-50/50 dark:bg-slate-800/50 hover:bg-purple-50/50 dark:hover:bg-purple-950/30'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-lg bg-purple-100 dark:bg-purple-900/40 text-purple-600 dark:text-purple-400">
                      <FileCode className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-sm text-slate-900 dark:text-white">JSON Backup (.json)</span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                    Data Backup
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  Full structured JSON file containing all sections and custom styling to restore or transfer anytime.
                </p>
              </div>
              <div className="mt-3 pt-2 flex items-center justify-between text-xs font-bold text-purple-600 dark:text-purple-400 group-hover:translate-x-1 transition-transform">
                <span>Export JSON Data</span>
                <Download className="w-4 h-4" />
              </div>
            </div>

          </div>

          {/* Quick Tip Footer */}
          <div className="p-3 bg-blue-50 dark:bg-slate-800/80 rounded-xl border border-blue-100 dark:border-slate-700 flex items-start gap-2.5 text-xs text-slate-700 dark:text-slate-300">
            <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-slate-900 dark:text-white">Pro Tip for Job Applications: </span>
              Use <strong className="text-blue-600 dark:text-blue-400">PDF</strong> when emailing recruiters or submitting direct attachments. Use <strong className="text-emerald-600 dark:text-emerald-400">Plain Text</strong> when pasting into online applicant portals.
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            disabled={isGenerating}
            className="px-5 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 text-xs font-bold transition-colors disabled:opacity-50"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};

import React from 'react';

interface QrCodeProps {
  value: string;
  size?: number;
  className?: string;
  color?: string;
}

export const QrCode: React.FC<QrCodeProps> = ({ value, size = 64, className = '', color = '#000000' }) => {
  // Simple deterministic pattern generator for clean SVG visual QR representation
  const generatePattern = (str: string) => {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = (hash << 5) - hash + str.charCodeAt(i);
      hash |= 0;
    }
    const grid: boolean[][] = Array(7).fill(false).map(() => Array(7).fill(false));
    
    // Position detection patterns (corners)
    for (let r = 0; r < 7; r++) {
      for (let c = 0; c < 7; c++) {
        // top-left corner box
        if (r < 3 && c < 3) grid[r][c] = r === 0 || r === 2 || c === 0 || c === 2;
        // top-right corner box
        else if (r < 3 && c > 3) grid[r][c] = r === 0 || r === 2 || c === 4 || c === 6;
        // bottom-left corner box
        else if (r > 3 && c < 3) grid[r][c] = r === 4 || r === 6 || c === 0 || c === 2;
        else {
          const val = Math.abs(hash * (r * 7 + c + 1)) % 10;
          grid[r][c] = val > 4;
        }
      }
    }
    return grid;
  };

  const grid = generatePattern(value || 'https://smartresume.example');
  const cellSize = size / 7;

  return (
    <div className={`inline-block p-1 bg-white rounded border border-gray-200 ${className}`} title={`QR Link: ${value}`}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {grid.map((row, r) =>
          row.map((cell, c) =>
            cell ? (
              <rect
                key={`${r}-${c}`}
                x={c * cellSize}
                y={r * cellSize}
                width={cellSize - 0.5}
                height={cellSize - 0.5}
                fill={color}
                rx={0.5}
              />
            ) : null
          )
        )}
      </svg>
    </div>
  );
};

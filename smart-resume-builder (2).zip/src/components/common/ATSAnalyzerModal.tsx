import React, { useState } from 'react';
import { ResumeData, ATSAnalysisResult } from '../../types/resume';
import { calculateAtsScore } from '../../services/aiService';
import { Sparkles, X, CheckCircle2, AlertTriangle, Check, ArrowRight } from 'lucide-react';

interface ATSAnalyzerModalProps {
  isOpen: boolean;
  onClose: () => void;
  resumeData: ResumeData;
  onApplyKeyword?: (keyword: string) => void;
}

export const ATSAnalyzerModal: React.FC<ATSAnalyzerModalProps> = ({
  isOpen,
  onClose,
  resumeData,
  onApplyKeyword,
}) => {
  const [jobDescription, setJobDescription] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [result, setResult] = useState<ATSAnalysisResult | null>(null);

  if (!isOpen) return null;

  const handleRunAnalysis = async () => {
    if (!jobDescription.trim()) {
      alert('Please paste a job description to perform ATS analysis.');
      return;
    }
    setIsAnalyzing(true);
    try {
      const resumeText = JSON.stringify(resumeData);
      const res = await calculateAtsScore(resumeText, jobDescription);
      setResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8">
        {/* Modal Header */}
        <div className="p-5 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-200 animate-pulse" />
            <div>
              <h2 className="text-lg font-bold">ATS Resume Score & Keyword Optimizer</h2>
              <p className="text-xs text-emerald-100">Scan your resume against target job requirements</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 text-xs max-h-[80vh] overflow-y-auto">
          {/* Input Box */}
          <div>
            <label className="block text-slate-800 dark:text-slate-200 font-bold mb-1.5">
              Paste Target Job Posting / Job Description
            </label>
            <textarea
              rows={4}
              value={jobDescription}
              onChange={e => setJobDescription(e.target.value)}
              placeholder="e.g. Seeking a Senior Full Stack Engineer proficient in React, TypeScript, Node.js, Microservices, CI/CD pipelines, Docker, and Cloud architecture..."
              className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 focus:ring-2 focus:ring-emerald-500 focus:outline-none leading-relaxed"
            />
            <button
              onClick={handleRunAnalysis}
              disabled={isAnalyzing}
              className="mt-3 w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-98"
            >
              <Sparkles className="w-4 h-4" />
              {isAnalyzing ? 'Scanning Resume & Matching Keywords...' : 'Run Real-Time ATS Audit'}
            </button>
          </div>

          {/* Results View */}
          {result && (
            <div className="space-y-6 pt-4 border-t border-slate-200 dark:border-slate-800">
              {/* Overall Score Badge */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg">
                <div className="flex items-center gap-4">
                  <div className="relative flex items-center justify-center w-20 h-20 rounded-full bg-emerald-500/20 border-4 border-emerald-400 font-extrabold text-2xl text-emerald-300">
                    {result.overallScore}%
                  </div>
                  <div>
                    <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest block">ATS Compatibility</span>
                    <h3 className="text-lg font-extrabold text-white">
                      {result.overallScore >= 85 ? 'Excellent ATS Match!' : result.overallScore >= 70 ? 'Good Match - Needs Minor Fixes' : 'Needs Optimization'}
                    </h3>
                    <p className="text-xs text-slate-300 mt-1">
                      Target Job Title: <span className="font-semibold text-white">{resumeData.personalInfo.jobTitle}</span>
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3 text-center text-[10px] w-full sm:w-auto">
                  <div className="p-2 bg-white/10 rounded-lg">
                    <span className="block text-slate-300">Keywords</span>
                    <span className="font-bold text-sm text-emerald-300">{result.matchedKeywords.length} Matched</span>
                  </div>
                  <div className="p-2 bg-white/10 rounded-lg">
                    <span className="block text-slate-300">Formatting</span>
                    <span className="font-bold text-sm text-blue-300">{result.formattingScore}%</span>
                  </div>
                  <div className="p-2 bg-white/10 rounded-lg">
                    <span className="block text-slate-300">Content</span>
                    <span className="font-bold text-sm text-purple-300">{result.contentScore}%</span>
                  </div>
                </div>
              </div>

              {/* Matched & Missing Keywords */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Matched */}
                <div className="p-4 bg-emerald-50 dark:bg-emerald-950/30 rounded-xl border border-emerald-200 dark:border-emerald-800/50">
                  <h4 className="font-bold text-emerald-900 dark:text-emerald-300 flex items-center gap-1.5 mb-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Matched Keywords ({result.matchedKeywords.length})
                  </h4>
                  <div className="flex flex-wrap gap-1">
                    {result.matchedKeywords.map((kw, i) => (
                      <span key={i} className="px-2 py-0.5 rounded bg-emerald-200/60 dark:bg-emerald-900 text-emerald-900 dark:text-emerald-200 text-[10px] font-semibold">
                        ✓ {kw}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Missing Keywords */}
                <div className="p-4 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200 dark:border-amber-800/50">
                  <h4 className="font-bold text-amber-900 dark:text-amber-300 flex items-center gap-1.5 mb-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    Missing Critical Keywords ({result.missingKeywords.length})
                  </h4>
                  <div className="flex flex-wrap gap-1">
                    {result.missingKeywords.map((kw, i) => (
                      <span
                        key={i}
                        onClick={() => onApplyKeyword?.(kw)}
                        className="px-2 py-0.5 rounded bg-amber-200/80 dark:bg-amber-900 text-amber-950 dark:text-amber-100 text-[10px] font-semibold cursor-pointer hover:bg-amber-300 flex items-center gap-1"
                        title="Click to add to skills"
                      >
                        + {kw}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actionable Suggestions List */}
              <div className="space-y-2">
                <h4 className="font-bold text-slate-800 dark:text-slate-100 text-xs">
                  Actionable Recommendations to Reach 95%+ ATS Score:
                </h4>
                <div className="space-y-2">
                  {result.suggestions.map((sug, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex gap-3 items-start">
                      <div className="p-1.5 bg-blue-100 dark:bg-blue-900/50 rounded-lg text-blue-600 shrink-0 mt-0.5">
                        <ArrowRight className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-slate-900 dark:text-white">{sug.category}</span>
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                            Action Fix
                          </span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-300 mt-0.5">{sug.message}</p>
                        <p className="text-emerald-700 dark:text-emerald-300 font-semibold mt-1 bg-emerald-50 dark:bg-emerald-950/40 p-2 rounded">
                          💡 Fix: {sug.actionableFix}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

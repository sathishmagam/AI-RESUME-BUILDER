import React, { useState } from 'react';
import { ResumeData } from '../../types/resume';
import { generateCoverLetter } from '../../services/aiService';
import { downloadCoverLetterAsDoc, downloadCoverLetterAsTxt } from '../../utils/documentExporter';
import { FileText, Sparkles, X, Copy, Check, Download, FileDown } from 'lucide-react';

interface CoverLetterModalProps {
  isOpen: boolean;
  onClose: () => void;
  resumeData: ResumeData;
}

export const CoverLetterModal: React.FC<CoverLetterModalProps> = ({
  isOpen,
  onClose,
  resumeData,
}) => {
  const [companyName, setCompanyName] = useState<string>('Google');
  const [jobRole, setJobRole] = useState<string>(resumeData.personalInfo.jobTitle || 'Senior Software Engineer');
  const [jobDesc, setJobDesc] = useState<string>('');
  const [tone, setTone] = useState<'professional' | 'enthusiastic' | 'confident' | 'creative'>('professional');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generatedLetter, setGeneratedLetter] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleGenerate = async () => {
    if (!companyName.trim() || !jobRole.trim()) {
      alert('Please enter company name and job role.');
      return;
    }
    setIsGenerating(true);
    try {
      const letter = await generateCoverLetter({
        candidateName: resumeData.personalInfo.fullName || 'Candidate Name',
        companyName,
        jobRole,
        resumeSummary: resumeData.personalInfo.summary || '',
        jobDescription: jobDesc,
        tone,
      });
      setGeneratedLetter(letter);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generatedLetter);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadDoc = () => {
    downloadCoverLetterAsDoc(
      generatedLetter,
      resumeData.personalInfo.fullName || 'Candidate',
      companyName || 'Company'
    );
  };

  const handleDownloadTxt = () => {
    downloadCoverLetterAsTxt(
      generatedLetter,
      resumeData.personalInfo.fullName || 'Candidate',
      companyName || 'Company'
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-purple-600 to-indigo-700 text-white flex justify-between items-center">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-purple-200" />
            <div>
              <h2 className="text-lg font-bold">AI Cover Letter Generator</h2>
              <p className="text-xs text-purple-100">Tailored cover letters generated instantly from your resume data</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/20 text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form & Output */}
        <div className="p-6 space-y-4 text-xs max-h-[80vh] overflow-y-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Company Name *</label>
              <input
                type="text"
                value={companyName}
                onChange={e => setCompanyName(e.target.value)}
                placeholder="Google / Stripe / Startup"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Target Job Role *</label>
              <input
                type="text"
                value={jobRole}
                onChange={e => setJobRole(e.target.value)}
                placeholder="Senior React Developer"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Tone</label>
              <select
                value={tone}
                onChange={e => setTone(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              >
                <option value="professional">Professional & Formal</option>
                <option value="enthusiastic">Enthusiastic & Driven</option>
                <option value="confident">Confident & Experienced</option>
                <option value="creative">Creative & Modern</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Job Details / Context (Optional)</label>
              <input
                type="text"
                value={jobDesc}
                onChange={e => setJobDesc(e.target.value)}
                placeholder="Key requirements from job post..."
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all active:scale-98"
          >
            <Sparkles className="w-4 h-4" />
            {isGenerating ? 'Generating Tailored Cover Letter with AI...' : '✨ Generate Cover Letter'}
          </button>

          {/* Generated Textbox */}
          {generatedLetter && (
            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex flex-wrap justify-between items-center gap-2">
                <span className="font-bold text-slate-800 dark:text-slate-200">Generated Cover Letter</span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopy}
                    className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-800 dark:text-slate-200 font-semibold flex items-center gap-1"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? 'Copied!' : 'Copy Text'}
                  </button>
                  <button
                    onClick={handleDownloadDoc}
                    className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold flex items-center gap-1"
                  >
                    <FileDown className="w-3.5 h-3.5" />
                    <span>Download .doc</span>
                  </button>
                  <button
                    onClick={handleDownloadTxt}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download .txt</span>
                  </button>
                </div>
              </div>

              <textarea
                rows={12}
                value={generatedLetter}
                onChange={e => setGeneratedLetter(e.target.value)}
                className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-serif text-xs leading-relaxed"
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};


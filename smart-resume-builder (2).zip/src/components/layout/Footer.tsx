import React from 'react';
import { Sparkles, Heart, Github, Twitter, Linkedin, Mail } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 text-xs py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold">
              <Sparkles className="w-4 h-4 text-yellow-300" />
            </div>
            <span className="text-base font-extrabold text-white tracking-tight">Smart Resume Builder</span>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed">
            Create ATS-compliant, professional resumes with AI bullet point optimization, live preview, and high-fidelity PDF export in under 5 minutes.
          </p>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="text-white font-bold mb-3 uppercase tracking-wider text-[11px]">Quick Links</h4>
          <ul className="space-y-2 text-slate-400">
            <li><button onClick={() => onNavigate('home')} className="hover:text-white">Home Page</button></li>
            <li><button onClick={() => onNavigate('templates')} className="hover:text-white">Resume Templates</button></li>
            <li><button onClick={() => onNavigate('dashboard')} className="hover:text-white">Dashboard</button></li>
            <li><button onClick={() => onNavigate('builder')} className="hover:text-white">Resume Builder</button></li>
          </ul>
        </div>

        {/* Templates */}
        <div>
          <h4 className="text-white font-bold mb-3 uppercase tracking-wider text-[11px]">Templates</h4>
          <ul className="space-y-2 text-slate-400">
            <li><button onClick={() => onNavigate('templates')} className="hover:text-white">Modern Professional</button></li>
            <li><button onClick={() => onNavigate('templates')} className="hover:text-white">Classic Serif</button></li>
            <li><button onClick={() => onNavigate('templates')} className="hover:text-white">Executive Leadership</button></li>
            <li><button onClick={() => onNavigate('templates')} className="hover:text-white">Tech Minimalist</button></li>
          </ul>
        </div>

        {/* Social & Contact */}
        <div>
          <h4 className="text-white font-bold mb-3 uppercase tracking-wider text-[11px]">Connect & Contact</h4>
          <p className="text-slate-400 text-xs mb-3">Have feedback or suggestions? Reach out anytime.</p>
          <div className="flex gap-3 text-slate-400">
            <a href="https://github.com" target="_blank" rel="noreferrer" className="p-2 bg-slate-800 rounded-lg hover:text-white hover:bg-slate-700">
              <Github className="w-4 h-4" />
            </a>
            <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="p-2 bg-slate-800 rounded-lg hover:text-white hover:bg-slate-700">
              <Linkedin className="w-4 h-4" />
            </a>
            <a href="mailto:support@smartresume.example" className="p-2 bg-slate-800 rounded-lg hover:text-white hover:bg-slate-700">
              <Mail className="w-4 h-4" />
            </a>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10 pt-6 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center text-slate-500 text-[11px]">
        <div>© 2026 Smart Resume Builder. All rights reserved.</div>
        <div className="mt-2 sm:mt-0 flex items-center gap-1">
          Crafted with <Heart className="w-3 h-3 text-red-500 fill-red-500" /> for job seekers worldwide.
        </div>
      </div>
    </footer>
  );
};

import React, { useState } from 'react';
import { ResumeData } from '../../types/resume';
import { FormPersonalInfo } from './FormPersonalInfo';
import { FormWorkExperience } from './FormWorkExperience';
import { FormEducation } from './FormEducation';
import { FormProjects } from './FormProjects';
import { FormSkills } from './FormSkills';
import { FormCertificationsAchievements } from './FormCertificationsAchievements';
import { FormInterestsReferences } from './FormInterestsReferences';
import { ResumePreview } from '../preview/ResumePreview';
import { ATSAnalyzerModal } from '../common/ATSAnalyzerModal';
import { CoverLetterModal } from '../common/CoverLetterModal';
import {
  User,
  Briefcase,
  GraduationCap,
  FolderGit2,
  Cpu,
  Award,
  Heart,
  Eye,
  Edit3,
  Download,
  Upload,
  Sparkles,
  Save,
  ArrowLeft,
  Check
} from 'lucide-react';

interface ResumeBuilderProps {
  resume: ResumeData;
  onSaveResume: (updatedResume: ResumeData) => void;
  onBackToDashboard: () => void;
}

type BuilderTab = 'personal' | 'experience' | 'education' | 'projects' | 'skills' | 'certs' | 'interests';

export const ResumeBuilder: React.FC<ResumeBuilderProps> = ({
  resume: initialResume,
  onSaveResume,
  onBackToDashboard,
}) => {
  const [resumeData, setResumeData] = useState<ResumeData>(initialResume);
  const [activeTab, setActiveTab] = useState<BuilderTab>('personal');
  const [mobileView, setMobileView] = useState<'editor' | 'preview'>('editor');
  const [isAtsOpen, setIsAtsOpen] = useState(false);
  const [isCoverLetterOpen, setIsCoverLetterOpen] = useState(false);
  const [saveNotification, setSaveNotification] = useState(false);

  const handleUpdate = (updatedFields: Partial<ResumeData>) => {
    const updated = {
      ...resumeData,
      ...updatedFields,
      updatedAt: new Date().toISOString(),
    };
    setResumeData(updated);
    onSaveResume(updated);
  };

  const handleSaveClick = () => {
    onSaveResume(resumeData);
    setSaveNotification(true);
    setTimeout(() => setSaveNotification(false), 2000);
  };

  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(resumeData, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `${resumeData.title.replace(/\s+/g, '_')}_draft.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handleImportJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const imported = JSON.parse(event.target?.result as string);
        if (imported.personalInfo) {
          setResumeData(imported);
          onSaveResume(imported);
          alert('Resume draft imported successfully!');
        }
      } catch (err) {
        alert('Invalid JSON file format.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-64px)] bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 overflow-hidden">
      {/* Top Action Header Bar */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToDashboard}
            className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition-colors flex items-center gap-1 text-xs font-semibold"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Dashboard</span>
          </button>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-700" />

          {/* Editable Resume Title */}
          <input
            type="text"
            value={resumeData.title}
            onChange={e => handleUpdate({ title: e.target.value })}
            className="text-sm font-bold bg-transparent border-b border-transparent hover:border-slate-300 focus:border-blue-500 focus:outline-none px-1 py-0.5 text-slate-800 dark:text-slate-100"
            title="Click to rename resume draft"
          />
        </div>

        {/* Right Toolbar */}
        <div className="flex items-center gap-2">
          {/* Mobile Switcher Toggle (Editor vs Preview) */}
          <div className="flex lg:hidden bg-slate-100 dark:bg-slate-800 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
            <button
              onClick={() => setMobileView('editor')}
              className={`px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1 ${
                mobileView === 'editor' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-2xs' : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <Edit3 className="w-3.5 h-3.5" /> Edit
            </button>
            <button
              onClick={() => setMobileView('preview')}
              className={`px-3 py-1 rounded-md text-xs font-semibold flex items-center gap-1 ${
                mobileView === 'preview' ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-blue-400 shadow-2xs' : 'text-slate-600 dark:text-slate-300'
              }`}
            >
              <Eye className="w-3.5 h-3.5" /> Preview
            </button>
          </div>

          {/* Save Button */}
          <button
            onClick={handleSaveClick}
            className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-100 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            {saveNotification ? <Check className="w-4 h-4 text-emerald-500" /> : <Save className="w-4 h-4 text-blue-600" />}
            <span>{saveNotification ? 'Saved!' : 'Save Draft'}</span>
          </button>

          {/* JSON Export/Import */}
          <button
            onClick={handleExportJson}
            title="Export JSON Backup"
            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs"
          >
            <Download className="w-4 h-4" />
          </button>
          <label
            title="Import JSON Backup"
            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs cursor-pointer"
          >
            <Upload className="w-4 h-4" />
            <input type="file" accept=".json" onChange={handleImportJson} className="hidden" />
          </label>
        </div>
      </div>

      {/* Main Split Body Container */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Form Editor Panel (Visible on desktop or when mobileView === 'editor') */}
        <div
          className={`w-full lg:w-1/2 flex flex-col bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 ${
            mobileView === 'preview' ? 'hidden lg:flex' : 'flex'
          }`}
        >
          {/* Form Tabs Bar */}
          <div className="p-2 border-b border-slate-200 dark:border-slate-800 flex gap-1 overflow-x-auto bg-slate-50 dark:bg-slate-900/50 shrink-0">
            {[
              { id: 'personal', label: 'Personal', icon: User },
              { id: 'experience', label: 'Experience', icon: Briefcase },
              { id: 'education', label: 'Education', icon: GraduationCap },
              { id: 'projects', label: 'Projects', icon: FolderGit2 },
              { id: 'skills', label: 'Skills', icon: Cpu },
              { id: 'certs', label: 'Certs & Awards', icon: Award },
              { id: 'interests', label: 'Interests & Refs', icon: Heart },
            ].map(tab => {
              const IconComp = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as BuilderTab)}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-slate-200/60 dark:hover:bg-slate-800'
                  }`}
                >
                  <IconComp className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* Form Active Tab Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            {activeTab === 'personal' && (
              <FormPersonalInfo
                data={resumeData.personalInfo}
                onChange={personalInfo => handleUpdate({ personalInfo })}
              />
            )}

            {activeTab === 'experience' && (
              <FormWorkExperience
                items={resumeData.experience}
                onChange={experience => handleUpdate({ experience })}
                defaultJobTitle={resumeData.personalInfo.jobTitle}
              />
            )}

            {activeTab === 'education' && (
              <FormEducation
                items={resumeData.education}
                onChange={education => handleUpdate({ education })}
              />
            )}

            {activeTab === 'projects' && (
              <FormProjects
                items={resumeData.projects}
                onChange={projects => handleUpdate({ projects })}
              />
            )}

            {activeTab === 'skills' && (
              <FormSkills
                skills={resumeData.skills}
                onChange={skills => handleUpdate({ skills })}
                targetJobTitle={resumeData.personalInfo.jobTitle}
              />
            )}

            {activeTab === 'certs' && (
              <FormCertificationsAchievements
                certifications={resumeData.certifications}
                achievements={resumeData.achievements}
                onChangeCerts={certifications => handleUpdate({ certifications })}
                onChangeAchievements={achievements => handleUpdate({ achievements })}
              />
            )}

            {activeTab === 'interests' && (
              <FormInterestsReferences
                interests={resumeData.interests}
                references={resumeData.references}
                onChangeInterests={interests => handleUpdate({ interests })}
                onChangeReferences={references => handleUpdate({ references })}
              />
            )}
          </div>
        </div>

        {/* Right Live Preview Panel (Visible on desktop or when mobileView === 'preview') */}
        <div
          className={`w-full lg:w-1/2 p-4 sm:p-6 overflow-hidden ${
            mobileView === 'editor' ? 'hidden lg:flex' : 'flex'
          }`}
        >
          <ResumePreview
            data={resumeData}
            onChangeStyle={styleUpdate => handleUpdate({ style: { ...resumeData.style, ...styleUpdate } })}
            onOpenAtsModal={() => setIsAtsOpen(true)}
            onOpenCoverLetterModal={() => setIsCoverLetterOpen(true)}
          />
        </div>
      </div>

      {/* ATS Optimizer Modal */}
      <ATSAnalyzerModal
        isOpen={isAtsOpen}
        onClose={() => setIsAtsOpen(false)}
        resumeData={resumeData}
        onApplyKeyword={kw => {
          if (!resumeData.skills.technical.includes(kw)) {
            handleUpdate({
              skills: {
                ...resumeData.skills,
                technical: [...resumeData.skills.technical, kw],
              },
            });
            alert(`Added "${kw}" to Technical Skills!`);
          }
        }}
      />

      {/* Cover Letter Generator Modal */}
      <CoverLetterModal
        isOpen={isCoverLetterOpen}
        onClose={() => setIsCoverLetterOpen(false)}
        resumeData={resumeData}
      />
    </div>
  );
};

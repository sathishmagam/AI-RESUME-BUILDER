import React from 'react';
import { Project } from '../../types/resume';
import { FolderGit2, Plus, Trash2 } from 'lucide-react';

interface FormProjectsProps {
  items: Project[];
  onChange: (items: Project[]) => void;
}

export const FormProjects: React.FC<FormProjectsProps> = ({ items, onChange }) => {
  const handleAdd = () => {
    const newItem: Project = {
      id: `proj_${Date.now()}`,
      title: 'Project Title',
      subtitle: 'Full Stack App',
      technologies: ['React', 'Node.js', 'Tailwind CSS'],
      githubUrl: 'https://github.com/...',
      liveUrl: 'https://example.com',
      description: 'Built a full-featured web application that solves key user pain points.',
    };
    onChange([newItem, ...items]);
  };

  const handleUpdate = (id: string, field: keyof Project, value: any) => {
    onChange(items.map(item => (item.id === id ? { ...item, [field]: value } : item)));
  };

  const handleTechChange = (id: string, techString: string) => {
    const techArray = techString.split(',').map(t => t.trim()).filter(Boolean);
    handleUpdate(id, 'technologies', techArray);
  };

  const handleDelete = (id: string) => {
    onChange(items.filter(item => item.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <FolderGit2 className="w-5 h-5 text-blue-600" />
          Projects & Portfolio
        </h2>
        <button
          type="button"
          onClick={handleAdd}
          className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1 transition-all shadow-xs"
        >
          <Plus className="w-4 h-4" />
          Add Project
        </button>
      </div>

      {items.length === 0 ? (
        <div className="p-6 text-center border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl">
          <p className="text-xs text-slate-500 mb-2">No projects added yet.</p>
          <button
            onClick={handleAdd}
            className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-600 font-semibold text-xs inline-flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" /> Add Project
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map(item => (
            <div key={item.id} className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3 text-xs shadow-2xs">
              <div className="flex justify-between items-start">
                <span className="font-bold text-slate-800 dark:text-slate-100 text-xs">Project Info</span>
                <button
                  type="button"
                  onClick={() => handleDelete(item.id)}
                  className="p-1 text-red-500 hover:bg-red-50 rounded"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Project Name *</label>
                  <input
                    type="text"
                    value={item.title}
                    onChange={e => handleUpdate(item.id, 'title', e.target.value)}
                    placeholder="Smart Resume Builder"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Subtitle / Category</label>
                  <input
                    type="text"
                    value={item.subtitle || ''}
                    onChange={e => handleUpdate(item.id, 'subtitle', e.target.value)}
                    placeholder="Open Source Web App"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">GitHub Code Link</label>
                  <input
                    type="url"
                    value={item.githubUrl || ''}
                    onChange={e => handleUpdate(item.id, 'githubUrl', e.target.value)}
                    placeholder="https://github.com/user/project"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Live Demo Link</label>
                  <input
                    type="url"
                    value={item.liveUrl || ''}
                    onChange={e => handleUpdate(item.id, 'liveUrl', e.target.value)}
                    placeholder="https://myproject.com"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Technologies Used (Comma-separated)
                </label>
                <input
                  type="text"
                  value={item.technologies?.join(', ') || ''}
                  onChange={e => handleTechChange(item.id, e.target.value)}
                  placeholder="React, TypeScript, Tailwind CSS, Node.js"
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Project Description & Impact</label>
                <textarea
                  rows={2}
                  value={item.description}
                  onChange={e => handleUpdate(item.id, 'description', e.target.value)}
                  placeholder="Briefly describe what you built, features, and results achieved..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-xs leading-relaxed"
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

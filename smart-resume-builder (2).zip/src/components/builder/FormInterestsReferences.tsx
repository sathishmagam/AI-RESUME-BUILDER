import React, { useState } from 'react';
import { Reference } from '../../types/resume';
import { Heart, Users, Plus, X, Trash2 } from 'lucide-react';

interface FormInterestsReferencesProps {
  interests: string[];
  references: Reference[];
  onChangeInterests: (interests: string[]) => void;
  onChangeReferences: (refs: Reference[]) => void;
}

export const FormInterestsReferences: React.FC<FormInterestsReferencesProps> = ({
  interests,
  references,
  onChangeInterests,
  onChangeReferences,
}) => {
  const [interestInput, setInterestInput] = useState('');

  const addInterest = () => {
    if (interestInput.trim() && !interests.includes(interestInput.trim())) {
      onChangeInterests([...interests, interestInput.trim()]);
      setInterestInput('');
    }
  };

  const removeInterest = (item: string) => {
    onChangeInterests(interests.filter(i => i !== item));
  };

  const addReference = () => {
    const newRef: Reference = {
      id: `ref_${Date.now()}`,
      name: 'Jane Doe',
      position: 'VP of Engineering',
      company: 'Tech Solutions Inc.',
      email: 'jane.doe@example.com',
      phone: '+1 (555) 999-0000',
    };
    onChangeReferences([...references, newRef]);
  };

  const updateReference = (id: string, field: keyof Reference, val: string) => {
    onChangeReferences(references.map(r => (r.id === id ? { ...r, [field]: val } : r)));
  };

  const deleteReference = (id: string) => {
    onChangeReferences(references.filter(r => r.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Interests & Hobbies */}
      <div className="space-y-3">
        <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <Heart className="w-5 h-5 text-rose-500" />
          Interests & Hobbies
        </h2>

        <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
          <div className="flex gap-2">
            <input
              type="text"
              value={interestInput}
              onChange={e => setInterestInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  addInterest();
                }
              }}
              placeholder="Add interest (e.g. Open Source, Marathons, Chess)"
              className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
            />
            <button
              type="button"
              onClick={addInterest}
              className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-semibold flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Add
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5 pt-2">
            {interests.map(item => (
              <span
                key={item}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-50 dark:bg-rose-950 text-rose-700 dark:text-rose-200 border border-rose-200 dark:border-rose-800 font-medium"
              >
                {item}
                <button
                  type="button"
                  onClick={() => removeInterest(item)}
                  className="p-0.5 hover:bg-rose-200 dark:hover:bg-rose-900 rounded-full"
                >
                  <X className="w-3 h-3 text-rose-500" />
                </button>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Professional References */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-600" />
            References (Optional)
          </h2>
          <button
            type="button"
            onClick={addReference}
            className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold flex items-center gap-1 shadow-xs"
          >
            <Plus className="w-4 h-4" /> Add Reference
          </button>
        </div>

        {references.map(r => (
          <div key={r.id} className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="font-bold text-slate-800 dark:text-slate-100">Reference Contact</span>
              <button onClick={() => deleteReference(r.id)} className="p-1 text-red-500 hover:bg-red-50 rounded">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                value={r.name}
                onChange={e => updateReference(r.id, 'name', e.target.value)}
                placeholder="Name"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
              <input
                type="text"
                value={r.position}
                onChange={e => updateReference(r.id, 'position', e.target.value)}
                placeholder="Title / Position"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
              <input
                type="text"
                value={r.company}
                onChange={e => updateReference(r.id, 'company', e.target.value)}
                placeholder="Company"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
              <input
                type="email"
                value={r.email}
                onChange={e => updateReference(r.id, 'email', e.target.value)}
                placeholder="Email"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

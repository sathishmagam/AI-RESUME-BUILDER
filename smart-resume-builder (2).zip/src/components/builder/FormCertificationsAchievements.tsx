import React from 'react';
import { Certification, Achievement } from '../../types/resume';
import { Award, Trophy, Plus, Trash2 } from 'lucide-react';

interface FormCertificationsProps {
  certifications: Certification[];
  achievements: Achievement[];
  onChangeCerts: (certs: Certification[]) => void;
  onChangeAchievements: (achievements: Achievement[]) => void;
}

export const FormCertificationsAchievements: React.FC<FormCertificationsProps> = ({
  certifications,
  achievements,
  onChangeCerts,
  onChangeAchievements,
}) => {
  const addCert = () => {
    const newCert: Certification = {
      id: `cert_${Date.now()}`,
      title: 'AWS Certified Solutions Architect',
      issuer: 'Amazon Web Services',
      date: '2025-06',
    };
    onChangeCerts([newCert, ...certifications]);
  };

  const updateCert = (id: string, field: keyof Certification, val: string) => {
    onChangeCerts(certifications.map(c => (c.id === id ? { ...c, [field]: val } : c)));
  };

  const deleteCert = (id: string) => {
    onChangeCerts(certifications.filter(c => c.id !== id));
  };

  const addAch = () => {
    const newAch: Achievement = {
      id: `ach_${Date.now()}`,
      title: '1st Place Hackathon Winner',
      organization: 'Tech Conference 2025',
      date: '2025-09',
      description: 'Awarded top project out of 80 competing engineering teams.',
    };
    onChangeAchievements([newAch, ...achievements]);
  };

  const updateAch = (id: string, field: keyof Achievement, val: string) => {
    onChangeAchievements(achievements.map(a => (a.id === id ? { ...a, [field]: val } : a)));
  };

  const deleteAch = (id: string) => {
    onChangeAchievements(achievements.filter(a => a.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Certifications Section */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Award className="w-5 h-5 text-blue-600" />
            Certifications & Licenses
          </h2>
          <button
            type="button"
            onClick={addCert}
            className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1 shadow-xs"
          >
            <Plus className="w-4 h-4" /> Add Certification
          </button>
        </div>

        {certifications.map(c => (
          <div key={c.id} className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="font-bold text-slate-800 dark:text-slate-100">Certification Details</span>
              <button onClick={() => deleteCert(c.id)} className="p-1 text-red-500 hover:bg-red-50 rounded">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                value={c.title}
                onChange={e => updateCert(c.id, 'title', e.target.value)}
                placeholder="Certification Name"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
              <input
                type="text"
                value={c.issuer}
                onChange={e => updateCert(c.id, 'issuer', e.target.value)}
                placeholder="Issuing Organization"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
              <input
                type="text"
                value={c.date}
                onChange={e => updateCert(c.id, 'date', e.target.value)}
                placeholder="Issue Date (e.g. 2025-05)"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>
          </div>
        ))}
      </div>

      {/* Achievements Section */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-500" />
            Achievements & Awards
          </h2>
          <button
            type="button"
            onClick={addAch}
            className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold flex items-center gap-1 shadow-xs"
          >
            <Plus className="w-4 h-4" /> Add Achievement
          </button>
        </div>

        {achievements.map(a => (
          <div key={a.id} className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="font-bold text-slate-800 dark:text-slate-100">Award / Honor Details</span>
              <button onClick={() => deleteAch(a.id)} className="p-1 text-red-500 hover:bg-red-50 rounded">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <input
                type="text"
                value={a.title}
                onChange={e => updateAch(a.id, 'title', e.target.value)}
                placeholder="Award Title"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
              <input
                type="text"
                value={a.organization}
                onChange={e => updateAch(a.id, 'organization', e.target.value)}
                placeholder="Granting Body / Host"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
              <input
                type="text"
                value={a.date}
                onChange={e => updateAch(a.id, 'date', e.target.value)}
                placeholder="Date Received"
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

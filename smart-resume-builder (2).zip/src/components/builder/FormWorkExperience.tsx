import React, { useState } from 'react';
import { WorkExperience } from '../../types/resume';
import { Briefcase, Plus, Trash2, Sparkles, ChevronDown, ChevronUp } from 'lucide-react';
import { enhanceAiBullet } from '../../services/aiService';

interface FormWorkExperienceProps {
  items: WorkExperience[];
  onChange: (items: WorkExperience[]) => void;
  defaultJobTitle?: string;
}

export const FormWorkExperience: React.FC<FormWorkExperienceProps> = ({ items, onChange, defaultJobTitle = '' }) => {
  const [expandedId, setExpandedId] = useState<string | null>(items[0]?.id || null);
  const [enhancingId, setEnhancingId] = useState<string | null>(null);
  const [enhancedOptions, setEnhancedOptions] = useState<{ id: string; bullets: string[] } | null>(null);

  const handleAdd = () => {
    const newItem: WorkExperience = {
      id: `exp_${Date.now()}`,
      jobTitle: defaultJobTitle || 'Software Engineer',
      company: '',
      location: '',
      startDate: '',
      endDate: '',
      isCurrent: false,
      description: '• Implemented key features resulting in improved user satisfaction.\n• Collaborated with team members to deliver core project milestones.',
    };
    onChange([newItem, ...items]);
    setExpandedId(newItem.id);
  };

  const handleUpdate = (id: string, field: keyof WorkExperience, value: any) => {
    onChange(items.map(item => (item.id === id ? { ...item, [field]: value } : item)));
  };

  const handleDelete = (id: string) => {
    onChange(items.filter(item => item.id !== id));
  };

  const handleTriggerAiEnhance = async (item: WorkExperience) => {
    setEnhancingId(item.id);
    try {
      const bullets = await enhanceAiBullet(item.jobTitle || 'Software Engineer', item.description);
      setEnhancedOptions({ id: item.id, bullets });
    } catch (err) {
      console.error(err);
    } finally {
      setEnhancingId(null);
    }
  };

  const applyBullet = (itemId: string, bulletText: string) => {
    const item = items.find(i => i.id === itemId);
    if (!item) return;
    const updatedDesc = item.description ? `${item.description}\n${bulletText}` : bulletText;
    handleUpdate(itemId, 'description', updatedDesc);
    setEnhancedOptions(null);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <Briefcase className="w-5 h-5 text-blue-600" />
          Work Experience
        </h2>
        <button
          type="button"
          onClick={handleAdd}
          className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1 transition-all shadow-xs"
        >
          <Plus className="w-4 h-4" />
          Add Experience
        </button>
      </div>

      {items.length === 0 ? (
        <div className="p-6 text-center border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl">
          <p className="text-xs text-slate-500 mb-2">No work experience added yet.</p>
          <button
            onClick={handleAdd}
            className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 font-semibold text-xs inline-flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" /> Add First Experience
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map(item => {
            const isExpanded = expandedId === item.id;
            return (
              <div
                key={item.id}
                className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden shadow-2xs"
              >
                {/* Accordion Bar */}
                <div
                  onClick={() => setExpandedId(isExpanded ? null : item.id)}
                  className="p-3 bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700/80 cursor-pointer flex justify-between items-center transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-xs text-slate-800 dark:text-slate-100">
                      {item.jobTitle || 'Untitled Position'}
                    </span>
                    {item.company && (
                      <span className="text-xs text-slate-500">at {item.company}</span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={e => {
                        e.stopPropagation();
                        handleDelete(item.id);
                      }}
                      className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/50 rounded"
                      title="Delete Entry"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </div>

                {/* Form Fields when Expanded */}
                {isExpanded && (
                  <div className="p-4 space-y-3 text-xs border-t border-slate-100 dark:border-slate-700">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Job Title *</label>
                        <input
                          type="text"
                          value={item.jobTitle}
                          onChange={e => handleUpdate(item.id, 'jobTitle', e.target.value)}
                          placeholder="Software Engineer"
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Company Name *</label>
                        <input
                          type="text"
                          value={item.company}
                          onChange={e => handleUpdate(item.id, 'company', e.target.value)}
                          placeholder="Acme Corp"
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Location</label>
                        <input
                          type="text"
                          value={item.location}
                          onChange={e => handleUpdate(item.id, 'location', e.target.value)}
                          placeholder="New York, NY (or Remote)"
                          className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Start Date</label>
                          <input
                            type="text"
                            value={item.startDate}
                            onChange={e => handleUpdate(item.id, 'startDate', e.target.value)}
                            placeholder="2023-01"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">End Date</label>
                          <input
                            type="text"
                            disabled={item.isCurrent}
                            value={item.isCurrent ? 'Present' : item.endDate}
                            onChange={e => handleUpdate(item.id, 'endDate', e.target.value)}
                            placeholder="2025-06"
                            className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white disabled:opacity-50"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id={`curr_${item.id}`}
                        checked={item.isCurrent}
                        onChange={e => handleUpdate(item.id, 'isCurrent', e.target.checked)}
                        className="rounded text-blue-600 focus:ring-blue-500"
                      />
                      <label htmlFor={`curr_${item.id}`} className="text-slate-700 dark:text-slate-300 font-medium cursor-pointer">
                        I currently work in this role
                      </label>
                    </div>

                    {/* Bullet Points / Description */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="block text-slate-700 dark:text-slate-300 font-semibold">
                          Responsibilities & Key Achievements
                        </label>
                        <button
                          type="button"
                          onClick={() => handleTriggerAiEnhance(item)}
                          disabled={enhancingId === item.id}
                          className="px-2.5 py-1 rounded bg-purple-600 hover:bg-purple-700 text-white text-[10px] font-bold flex items-center gap-1 shadow-2xs"
                        >
                          <Sparkles className="w-3 h-3" />
                          {enhancingId === item.id ? 'Optimizing Bullet Points...' : '✨ AI Quantify Bullet Points'}
                        </button>
                      </div>

                      <textarea
                        rows={4}
                        value={item.description}
                        onChange={e => handleUpdate(item.id, 'description', e.target.value)}
                        placeholder="• Architected microservices architecture handling 5M daily requests..."
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 text-xs leading-relaxed"
                      />

                      {/* AI Enhanced Bullet Options */}
                      {enhancedOptions && enhancedOptions.id === item.id && (
                        <div className="mt-2 p-3 bg-purple-50 dark:bg-purple-950/40 rounded-xl border border-purple-200 dark:border-purple-800 space-y-2">
                          <div className="flex justify-between items-center text-xs font-bold text-purple-900 dark:text-purple-200">
                            <span>✨ Select an AI Quantified Bullet to Append:</span>
                            <button
                              onClick={() => setEnhancedOptions(null)}
                              className="text-purple-500 hover:text-purple-700 text-xs font-bold"
                            >
                              Dismiss ✕
                            </button>
                          </div>
                          <div className="space-y-1.5">
                            {enhancedOptions.bullets.map((bText, bIdx) => (
                              <div
                                key={bIdx}
                                onClick={() => applyBullet(item.id, bText)}
                                className="p-2 bg-white dark:bg-slate-800 rounded border border-purple-100 dark:border-purple-900 hover:bg-purple-100/50 cursor-pointer text-xs text-slate-800 dark:text-slate-200 flex justify-between items-center"
                              >
                                <span>{bText}</span>
                                <span className="text-[10px] text-purple-600 font-bold ml-2 shrink-0">+ Add</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

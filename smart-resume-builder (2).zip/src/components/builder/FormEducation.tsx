import React from 'react';
import { Education } from '../../types/resume';
import { GraduationCap, Plus, Trash2 } from 'lucide-react';

interface FormEducationProps {
  items: Education[];
  onChange: (items: Education[]) => void;
}

export const FormEducation: React.FC<FormEducationProps> = ({ items, onChange }) => {
  const handleAdd = () => {
    const newItem: Education = {
      id: `edu_${Date.now()}`,
      degree: 'Bachelor of Science in Computer Science',
      institution: 'University Name',
      location: 'City, State',
      startDate: '2020-08',
      endDate: '2024-05',
      grade: '3.8 GPA',
      description: 'Relevant coursework: Algorithms, Data Structures, Web Engineering.',
    };
    onChange([newItem, ...items]);
  };

  const handleUpdate = (id: string, field: keyof Education, value: string) => {
    onChange(items.map(item => (item.id === id ? { ...item, [field]: value } : item)));
  };

  const handleDelete = (id: string) => {
    onChange(items.filter(item => item.id !== id));
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-blue-600" />
          Education & Qualifications
        </h2>
        <button
          type="button"
          onClick={handleAdd}
          className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center gap-1 transition-all shadow-xs"
        >
          <Plus className="w-4 h-4" />
          Add Education
        </button>
      </div>

      {items.length === 0 ? (
        <div className="p-6 text-center border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-xl">
          <p className="text-xs text-slate-500 mb-2">No education entries added yet.</p>
          <button
            onClick={handleAdd}
            className="px-3 py-1.5 rounded-lg bg-blue-50 text-blue-600 font-semibold text-xs inline-flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" /> Add Degree / School
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map(item => (
            <div key={item.id} className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3 text-xs shadow-2xs">
              <div className="flex justify-between items-start">
                <span className="font-bold text-slate-800 dark:text-slate-100 text-xs">Degree & College</span>
                <button
                  type="button"
                  onClick={() => handleDelete(item.id)}
                  className="p-1 text-red-500 hover:bg-red-50 rounded"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Degree / Program *</label>
                  <input
                    type="text"
                    value={item.degree}
                    onChange={e => handleUpdate(item.id, 'degree', e.target.value)}
                    placeholder="BS in Computer Science"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">University / College *</label>
                  <input
                    type="text"
                    value={item.institution}
                    onChange={e => handleUpdate(item.id, 'institution', e.target.value)}
                    placeholder="UC Berkeley"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Location</label>
                  <input
                    type="text"
                    value={item.location}
                    onChange={e => handleUpdate(item.id, 'location', e.target.value)}
                    placeholder="Berkeley, CA"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Grade / CGPA</label>
                  <input
                    type="text"
                    value={item.grade}
                    onChange={e => handleUpdate(item.id, 'grade', e.target.value)}
                    placeholder="3.8 / 4.0 GPA"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Start Year / Date</label>
                  <input
                    type="text"
                    value={item.startDate}
                    onChange={e => handleUpdate(item.id, 'startDate', e.target.value)}
                    placeholder="2020-08"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Graduation Year / Date</label>
                  <input
                    type="text"
                    value={item.endDate}
                    onChange={e => handleUpdate(item.id, 'endDate', e.target.value)}
                    placeholder="2024-05"
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Honors / Description</label>
                <input
                  type="text"
                  value={item.description}
                  onChange={e => handleUpdate(item.id, 'description', e.target.value)}
                  placeholder="Dean's List, Honors thesis, Coursework..."
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

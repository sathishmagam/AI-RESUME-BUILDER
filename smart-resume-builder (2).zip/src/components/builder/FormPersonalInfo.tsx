import React, { useState } from 'react';
import { PersonalInfo } from '../../types/resume';
import { Sparkles, User, Mail, Phone, MapPin, Linkedin, Github, Globe, Image } from 'lucide-react';
import { generateAiSummary } from '../../services/aiService';

interface FormPersonalInfoProps {
  data: PersonalInfo;
  onChange: (data: PersonalInfo) => void;
}

export const FormPersonalInfo: React.FC<FormPersonalInfoProps> = ({ data, onChange }) => {
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);
  const [aiSummaries, setAiSummaries] = useState<string[]>([]);
  const [showAiPicker, setShowAiPicker] = useState(false);

  const handleTextChange = (field: keyof PersonalInfo, value: string) => {
    onChange({ ...data, [field]: value });
  };

  const handleTriggerAiSummary = async () => {
    if (!data.jobTitle) {
      alert('Please enter a Job Title first so AI can generate tailored summaries.');
      return;
    }
    setIsGeneratingAi(true);
    setShowAiPicker(true);
    try {
      const summaries = await generateAiSummary(data.jobTitle, '3-5', [data.jobTitle]);
      setAiSummaries(summaries);
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const selectSummary = (summaryText: string) => {
    onChange({ ...data, summary: summaryText });
    setShowAiPicker(false);
  };

  return (
    <div className="space-y-4">
      <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
        <User className="w-5 h-5 text-blue-600" />
        Personal Details & Summary
      </h2>

      {/* Grid of Inputs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
        <div>
          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Full Name *</label>
          <input
            type="text"
            value={data.fullName}
            onChange={e => handleTextChange('fullName', e.target.value)}
            placeholder="Alex Morgan"
            className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Professional Title *</label>
          <input
            type="text"
            value={data.jobTitle}
            onChange={e => handleTextChange('jobTitle', e.target.value)}
            placeholder="Senior Full Stack Software Engineer"
            className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1 flex items-center gap-1">
            <Mail className="w-3.5 h-3.5 text-slate-400" /> Email Address
          </label>
          <input
            type="email"
            value={data.email}
            onChange={e => handleTextChange('email', e.target.value)}
            placeholder="alex.morgan@example.com"
            className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1 flex items-center gap-1">
            <Phone className="w-3.5 h-3.5 text-slate-400" /> Phone Number
          </label>
          <input
            type="tel"
            value={data.phone}
            onChange={e => handleTextChange('phone', e.target.value)}
            placeholder="+1 (555) 234-5678"
            className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1 flex items-center gap-1">
            <MapPin className="w-3.5 h-3.5 text-slate-400" /> Location / Address
          </label>
          <input
            type="text"
            value={data.address}
            onChange={e => handleTextChange('address', e.target.value)}
            placeholder="San Francisco, CA"
            className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1 flex items-center gap-1">
            <Linkedin className="w-3.5 h-3.5 text-blue-500" /> LinkedIn URL
          </label>
          <input
            type="url"
            value={data.linkedin}
            onChange={e => handleTextChange('linkedin', e.target.value)}
            placeholder="https://linkedin.com/in/alexmorgan"
            className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1 flex items-center gap-1">
            <Github className="w-3.5 h-3.5 text-slate-700 dark:text-slate-300" /> GitHub URL
          </label>
          <input
            type="url"
            value={data.github}
            onChange={e => handleTextChange('github', e.target.value)}
            placeholder="https://github.com/alexmorgan"
            className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div>
          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1 flex items-center gap-1">
            <Globe className="w-3.5 h-3.5 text-emerald-500" /> Portfolio Website
          </label>
          <input
            type="url"
            value={data.portfolio}
            onChange={e => handleTextChange('portfolio', e.target.value)}
            placeholder="https://alexmorgan.dev"
            className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>

        <div className="col-span-full">
          <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1 flex items-center gap-1">
            <Image className="w-3.5 h-3.5 text-purple-500" /> Profile Photo URL
          </label>
          <input
            type="url"
            value={data.photoUrl || ''}
            onChange={e => handleTextChange('photoUrl', e.target.value)}
            placeholder="https://images.unsplash.com/photo-..."
            className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Professional Summary Section with AI Generator */}
      <div className="pt-2">
        <div className="flex justify-between items-center mb-1.5">
          <label className="block text-slate-700 dark:text-slate-300 font-semibold text-xs">
            Professional Summary
          </label>
          <button
            type="button"
            onClick={handleTriggerAiSummary}
            disabled={isGeneratingAi}
            className="px-2.5 py-1 rounded-md bg-purple-600 hover:bg-purple-700 text-white text-[11px] font-semibold flex items-center gap-1 transition-all shadow-2xs"
          >
            <Sparkles className="w-3 h-3" />
            {isGeneratingAi ? 'Generating AI...' : '✨ AI Write Summary'}
          </button>
        </div>

        <textarea
          rows={4}
          value={data.summary}
          onChange={e => handleTextChange('summary', e.target.value)}
          placeholder="A brief overview of your professional background, key achievements, and skills..."
          className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:outline-none text-xs leading-relaxed"
        />

        {/* AI Options Picker Modal / Drawer */}
        {showAiPicker && (
          <div className="mt-3 p-3 bg-purple-50 dark:bg-purple-950/40 rounded-xl border border-purple-200 dark:border-purple-800 space-y-2">
            <div className="flex justify-between items-center text-xs font-bold text-purple-900 dark:text-purple-200">
              <span className="flex items-center gap-1">
                <Sparkles className="w-4 h-4 text-purple-600" /> Pick an AI-Generated Summary Option:
              </span>
              <button
                onClick={() => setShowAiPicker(false)}
                className="text-purple-500 hover:text-purple-700 text-xs font-bold"
              >
                Close ✕
              </button>
            </div>

            {isGeneratingAi ? (
              <div className="py-4 text-center text-xs text-purple-600 dark:text-purple-300 animate-pulse">
                Crafting professional summaries with Gemini AI...
              </div>
            ) : (
              <div className="space-y-2">
                {aiSummaries.map((sText, idx) => (
                  <div
                    key={idx}
                    onClick={() => selectSummary(sText)}
                    className="p-2.5 bg-white dark:bg-slate-800 rounded-lg border border-purple-100 dark:border-purple-900 hover:border-purple-500 cursor-pointer transition-colors text-xs text-slate-700 dark:text-slate-200 group"
                  >
                    <div className="text-[10px] font-bold text-purple-600 mb-0.5">Option #{idx + 1}</div>
                    <p className="group-hover:text-purple-900 dark:group-hover:text-purple-100">{sText}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

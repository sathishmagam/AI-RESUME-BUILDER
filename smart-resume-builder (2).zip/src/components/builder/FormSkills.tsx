import React, { useState } from 'react';
import { ResumeData } from '../../types/resume';
import { Cpu, Plus, X, Sparkles } from 'lucide-react';

interface FormSkillsProps {
  skills: ResumeData['skills'];
  onChange: (skills: ResumeData['skills']) => void;
  targetJobTitle?: string;
}

export const FormSkills: React.FC<FormSkillsProps> = ({ skills, onChange, targetJobTitle = '' }) => {
  const [techInput, setTechInput] = useState('');
  const [softInput, setSoftInput] = useState('');
  const [langName, setLangName] = useState('');
  const [langProf, setLangProf] = useState('Fluent');

  const addTechSkill = (skill: string) => {
    const trimmed = skill.trim();
    if (trimmed && !skills.technical.includes(trimmed)) {
      onChange({ ...skills, technical: [...skills.technical, trimmed] });
      setTechInput('');
    }
  };

  const removeTechSkill = (skill: string) => {
    onChange({ ...skills, technical: skills.technical.filter(s => s !== skill) });
  };

  const addSoftSkill = (skill: string) => {
    const trimmed = skill.trim();
    if (trimmed && !skills.soft.includes(trimmed)) {
      onChange({ ...skills, soft: [...skills.soft, trimmed] });
      setSoftInput('');
    }
  };

  const removeSoftSkill = (skill: string) => {
    onChange({ ...skills, soft: skills.soft.filter(s => s !== skill) });
  };

  const addLanguage = () => {
    if (langName.trim()) {
      onChange({
        ...skills,
        languages: [...skills.languages, { language: langName.trim(), proficiency: langProf }],
      });
      setLangName('');
    }
  };

  const removeLanguage = (idx: number) => {
    onChange({
      ...skills,
      languages: skills.languages.filter((_, i) => i !== idx),
    });
  };

  const suggestPresetSkills = () => {
    const presets = ['React.js', 'TypeScript', 'Node.js', 'Express.js', 'Tailwind CSS', 'PostgreSQL', 'Docker', 'REST APIs', 'Git', 'Agile/Scrum', 'GraphQL'];
    const newTech = Array.from(new Set([...skills.technical, ...presets]));
    onChange({ ...skills, technical: newTech });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
          <Cpu className="w-5 h-5 text-blue-600" />
          Skills & Languages
        </h2>
        <button
          type="button"
          onClick={suggestPresetSkills}
          className="px-2.5 py-1 rounded-lg bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold flex items-center gap-1 shadow-xs"
        >
          <Sparkles className="w-3.5 h-3.5" /> Quick Auto-Fill Skills
        </button>
      </div>

      {/* Technical Skills */}
      <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
        <label className="block text-slate-800 dark:text-slate-100 font-bold">
          Technical & Hard Skills
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            value={techInput}
            onChange={e => setTechInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addTechSkill(techInput);
              }
            }}
            placeholder="Type a skill (e.g. Python, AWS, Docker) & press Enter"
            className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
          />
          <button
            type="button"
            onClick={() => addTechSkill(techInput)}
            className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" /> Add
          </button>
        </div>

        <div className="flex flex-wrap gap-1.5 pt-2">
          {skills.technical.map(s => (
            <span
              key={s}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-200 border border-blue-200 dark:border-blue-800 font-medium"
            >
              {s}
              <button
                type="button"
                onClick={() => removeTechSkill(s)}
                className="p-0.5 hover:bg-blue-200 dark:hover:bg-blue-900 rounded-full"
              >
                <X className="w-3 h-3 text-blue-500" />
              </button>
            </span>
          ))}
        </div>
      </div>

      {/* Soft Skills */}
      <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
        <label className="block text-slate-800 dark:text-slate-100 font-bold">
          Soft Skills & Leadership
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            value={softInput}
            onChange={e => setSoftInput(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addSoftSkill(softInput);
              }
            }}
            placeholder="Type soft skill (e.g. Team Leadership, Public Speaking) & press Enter"
            className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
          />
          <button
            type="button"
            onClick={() => addSoftSkill(softInput)}
            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" /> Add
          </button>
        </div>

        <div className="flex flex-wrap gap-1.5 pt-2">
          {skills.soft.map(s => (
            <span
              key={s}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-200 border border-emerald-200 dark:border-emerald-800 font-medium"
            >
              {s}
              <button
                type="button"
                onClick={() => removeSoftSkill(s)}
                className="p-0.5 hover:bg-emerald-200 dark:hover:bg-emerald-900 rounded-full"
              >
                <X className="w-3 h-3 text-emerald-500" />
              </button>
            </span>
          ))}
        </div>
      </div>

      {/* Languages */}
      <div className="p-4 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
        <label className="block text-slate-800 dark:text-slate-100 font-bold">
          Languages Spoken
        </label>
        <div className="flex gap-2">
          <input
            type="text"
            value={langName}
            onChange={e => setLangName(e.target.value)}
            placeholder="Language (e.g. English, Spanish)"
            className="flex-1 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
          />
          <select
            value={langProf}
            onChange={e => setLangProf(e.target.value)}
            className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
          >
            <option value="Native / Fluent">Native / Fluent</option>
            <option value="Professional Working">Professional Working</option>
            <option value="Intermediate">Intermediate</option>
            <option value="Elementary">Elementary</option>
          </select>
          <button
            type="button"
            onClick={addLanguage}
            className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-semibold flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" /> Add
          </button>
        </div>

        <div className="space-y-1.5 pt-2">
          {skills.languages.map((l, idx) => (
            <div key={idx} className="flex justify-between items-center p-2 bg-slate-50 dark:bg-slate-700/50 rounded-lg">
              <span className="font-semibold text-slate-800 dark:text-slate-100">{l.language}</span>
              <div className="flex items-center gap-2">
                <span className="text-slate-500 text-[11px]">{l.proficiency}</span>
                <button
                  type="button"
                  onClick={() => removeLanguage(idx)}
                  className="p-1 text-red-500 hover:text-red-700"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

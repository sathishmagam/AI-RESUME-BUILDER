import React from 'react';
import { ResumeData } from '../../../types/resume';
import { QrCode } from '../../common/QrCode';

interface TemplateProps {
  data: ResumeData;
}

export const ClassicTemplate: React.FC<TemplateProps> = ({ data }) => {
  const { personalInfo, education, experience, projects, skills, certifications, achievements, references, style } = data;
  const primaryColor = style.primaryColor || '#1e3a8a';

  return (
    <div className="w-full bg-white text-gray-900 p-8 sm:p-12 font-serif text-sm leading-relaxed max-w-[850px] mx-auto shadow-sm print:shadow-none print:p-0">
      {/* Header */}
      <div className="text-center border-b pb-6 mb-6" style={{ borderColor: primaryColor }}>
        <div className="flex justify-between items-start">
          <div className="w-full">
            <h1 className="text-3xl font-bold uppercase tracking-wider text-gray-900 mb-1">
              {personalInfo.fullName || 'YOUR NAME'}
            </h1>
            <p className="text-base font-semibold italic text-gray-700 mb-3" style={{ color: primaryColor }}>
              {personalInfo.jobTitle || 'Professional Title'}
            </p>
            <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-xs text-gray-600 font-sans">
              {personalInfo.email && <span>📧 {personalInfo.email}</span>}
              {personalInfo.phone && <span>📞 {personalInfo.phone}</span>}
              {personalInfo.address && <span>📍 {personalInfo.address}</span>}
              {personalInfo.linkedin && (
                <a href={personalInfo.linkedin} target="_blank" rel="noreferrer" className="underline hover:text-blue-700">
                  LinkedIn
                </a>
              )}
              {personalInfo.github && (
                <a href={personalInfo.github} target="_blank" rel="noreferrer" className="underline hover:text-blue-700">
                  GitHub
                </a>
              )}
              {personalInfo.portfolio && (
                <a href={personalInfo.portfolio} target="_blank" rel="noreferrer" className="underline hover:text-blue-700">
                  Portfolio
                </a>
              )}
            </div>
          </div>
          {style.showQrCode && personalInfo.portfolio && (
            <div className="hidden sm:block pl-4">
              <QrCode value={personalInfo.portfolio} size={50} color={primaryColor} />
            </div>
          )}
        </div>
      </div>

      {/* Professional Summary */}
      {personalInfo.summary && (
        <div className="mb-6">
          <h2 className="text-xs font-bold uppercase tracking-widest pb-1 mb-2 border-b text-gray-800" style={{ borderColor: primaryColor, color: primaryColor }}>
            Professional Summary
          </h2>
          <p className="text-gray-700 text-justify leading-normal">{personalInfo.summary}</p>
        </div>
      )}

      {/* Experience */}
      {experience.length > 0 && (
        <div className="mb-6">
          <h2 className="text-xs font-bold uppercase tracking-widest pb-1 mb-3 border-b text-gray-800" style={{ borderColor: primaryColor, color: primaryColor }}>
            Work Experience
          </h2>
          <div className="space-y-4">
            {experience.map(exp => (
              <div key={exp.id}>
                <div className="flex justify-between items-baseline font-semibold text-gray-900">
                  <span className="text-base">{exp.jobTitle}</span>
                  <span className="text-xs text-gray-600 font-sans">
                    {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs italic text-gray-700 mb-1.5">
                  <span>{exp.company}</span>
                  <span>{exp.location}</span>
                </div>
                <div className="text-gray-700 text-xs whitespace-pre-line pl-2 border-l-2" style={{ borderColor: `${primaryColor}40` }}>
                  {exp.description}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {education.length > 0 && (
        <div className="mb-6">
          <h2 className="text-xs font-bold uppercase tracking-widest pb-1 mb-3 border-b text-gray-800" style={{ borderColor: primaryColor, color: primaryColor }}>
            Education
          </h2>
          <div className="space-y-3">
            {education.map(edu => (
              <div key={edu.id}>
                <div className="flex justify-between items-baseline font-semibold text-gray-900">
                  <span>{edu.degree}</span>
                  <span className="text-xs text-gray-600 font-sans">
                    {edu.startDate} – {edu.endDate}
                  </span>
                </div>
                <div className="flex justify-between text-xs italic text-gray-700">
                  <span>{edu.institution}, {edu.location}</span>
                  {edu.grade && <span className="font-sans font-medium">{edu.grade}</span>}
                </div>
                {edu.description && <p className="text-xs text-gray-600 mt-1">{edu.description}</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Projects */}
      {projects.length > 0 && (
        <div className="mb-6">
          <h2 className="text-xs font-bold uppercase tracking-widest pb-1 mb-3 border-b text-gray-800" style={{ borderColor: primaryColor, color: primaryColor }}>
            Key Projects
          </h2>
          <div className="space-y-3">
            {projects.map(proj => (
              <div key={proj.id}>
                <div className="flex justify-between items-baseline font-semibold text-gray-900">
                  <div className="flex items-center gap-2">
                    <span>{proj.title}</span>
                    {proj.subtitle && <span className="text-xs font-normal italic text-gray-600">({proj.subtitle})</span>}
                  </div>
                  <div className="text-xs font-sans text-gray-600 gap-2 flex">
                    {proj.githubUrl && <a href={proj.githubUrl} target="_blank" rel="noreferrer" className="underline">Code</a>}
                    {proj.liveUrl && <a href={proj.liveUrl} target="_blank" rel="noreferrer" className="underline">Demo</a>}
                  </div>
                </div>
                {proj.technologies && proj.technologies.length > 0 && (
                  <p className="text-xs text-gray-600 font-sans italic mb-1">
                    Tech Stack: {proj.technologies.join(', ')}
                  </p>
                )}
                <p className="text-xs text-gray-700">{proj.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {(skills.technical.length > 0 || skills.soft.length > 0) && (
        <div className="mb-6">
          <h2 className="text-xs font-bold uppercase tracking-widest pb-1 mb-2 border-b text-gray-800" style={{ borderColor: primaryColor, color: primaryColor }}>
            Skills & Competencies
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-sans">
            {skills.technical.length > 0 && (
              <div>
                <span className="font-bold text-gray-800">Technical Skills: </span>
                <span className="text-gray-700">{skills.technical.join(', ')}</span>
              </div>
            )}
            {skills.soft.length > 0 && (
              <div>
                <span className="font-bold text-gray-800">Soft Skills: </span>
                <span className="text-gray-700">{skills.soft.join(', ')}</span>
              </div>
            )}
            {skills.languages.length > 0 && (
              <div className="col-span-full">
                <span className="font-bold text-gray-800">Languages: </span>
                <span className="text-gray-700">
                  {skills.languages.map(l => `${l.language} (${l.proficiency})`).join(', ')}
                </span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Certifications & Achievements */}
      {(certifications.length > 0 || achievements.length > 0) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
          {certifications.length > 0 && (
            <div>
              <h2 className="text-xs font-bold uppercase tracking-widest pb-1 mb-2 border-b text-gray-800" style={{ borderColor: primaryColor, color: primaryColor }}>
                Certifications
              </h2>
              <ul className="list-disc list-inside text-xs text-gray-700 space-y-1">
                {certifications.map(c => (
                  <li key={c.id}>
                    <span className="font-semibold">{c.title}</span> – {c.issuer} ({c.date})
                  </li>
                ))}
              </ul>
            </div>
          )}
          {achievements.length > 0 && (
            <div>
              <h2 className="text-xs font-bold uppercase tracking-widest pb-1 mb-2 border-b text-gray-800" style={{ borderColor: primaryColor, color: primaryColor }}>
                Achievements
              </h2>
              <ul className="list-disc list-inside text-xs text-gray-700 space-y-1">
                {achievements.map(a => (
                  <li key={a.id}>
                    <span className="font-semibold">{a.title}</span> ({a.date})
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}

      {/* References */}
      {references.length > 0 && (
        <div>
          <h2 className="text-xs font-bold uppercase tracking-widest pb-1 mb-2 border-b text-gray-800" style={{ borderColor: primaryColor, color: primaryColor }}>
            References
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {references.map(r => (
              <div key={r.id}>
                <p className="font-bold text-gray-900">{r.name}</p>
                <p className="text-gray-600">{r.position}, {r.company}</p>
                <p className="text-gray-500 font-sans">{r.email} | {r.phone}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

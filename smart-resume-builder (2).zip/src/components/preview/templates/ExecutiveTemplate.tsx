import React from 'react';
import { ResumeData } from '../../../types/resume';
import { QrCode } from '../../common/QrCode';

interface TemplateProps {
  data: ResumeData;
}

export const ExecutiveTemplate: React.FC<TemplateProps> = ({ data }) => {
  const { personalInfo, education, experience, projects, skills, certifications, achievements, style } = data;
  const primaryColor = style.primaryColor || '#0f172a'; // Slate / Dark blue

  return (
    <div className="w-full bg-white text-gray-900 font-sans text-sm max-w-[850px] mx-auto shadow-sm print:shadow-none print:p-0">
      {/* Full Width Top Executive Banner */}
      <div className="text-white p-8 mb-6 flex flex-col sm:flex-row justify-between items-center" style={{ backgroundColor: primaryColor }}>
        <div>
          <h1 className="text-3xl font-extrabold tracking-wide uppercase">{personalInfo.fullName || 'ALEX MORGAN'}</h1>
          <p className="text-base font-light text-slate-200 tracking-wider uppercase mt-1">
            {personalInfo.jobTitle || 'CHIEF TECHNOLOGY OFFICER / SENIOR ENGINEER'}
          </p>
        </div>
        <div className="mt-4 sm:mt-0 text-right text-xs text-slate-300 space-y-1 font-mono">
          {personalInfo.email && <div>{personalInfo.email}</div>}
          {personalInfo.phone && <div>{personalInfo.phone}</div>}
          {personalInfo.address && <div>{personalInfo.address}</div>}
          {personalInfo.linkedin && (
            <div>
              <a href={personalInfo.linkedin} target="_blank" rel="noreferrer" className="underline hover:text-white">
                LinkedIn Profile
              </a>
            </div>
          )}
        </div>
      </div>

      <div className="px-8 pb-8 space-y-6">
        {/* Executive Summary */}
        {personalInfo.summary && (
          <div className="bg-slate-50 border-l-4 p-4 rounded-r-md" style={{ borderColor: primaryColor }}>
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-1">Executive Summary</h2>
            <p className="text-xs text-slate-700 leading-relaxed">{personalInfo.summary}</p>
          </div>
        )}

        {/* Core Competencies Matrix */}
        {skills.technical.length > 0 && (
          <div>
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-2 pb-1 border-b-2" style={{ borderColor: primaryColor }}>
              Core Competencies & Expertise
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-medium text-slate-700">
              {skills.technical.slice(0, 12).map((skill, i) => (
                <div key={i} className="flex items-center gap-1.5 bg-slate-100 px-2.5 py-1 rounded">
                  <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: primaryColor }} />
                  <span className="truncate">{skill}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Experience */}
        {experience.length > 0 && (
          <div>
            <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-3 pb-1 border-b-2" style={{ borderColor: primaryColor }}>
              Professional Experience
            </h2>
            <div className="space-y-4">
              {experience.map(exp => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline mb-0.5">
                    <span className="font-bold text-gray-900 text-sm">{exp.jobTitle}</span>
                    <span className="text-xs font-semibold text-slate-500">
                      {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate}
                    </span>
                  </div>
                  <div className="text-xs font-semibold italic text-slate-700 mb-1.5">
                    {exp.company} | {exp.location}
                  </div>
                  <p className="text-xs text-slate-700 whitespace-pre-line leading-normal">
                    {exp.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education & Credentials */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {education.length > 0 && (
            <div>
              <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-2 pb-1 border-b-2" style={{ borderColor: primaryColor }}>
                Education
              </h2>
              <div className="space-y-2">
                {education.map(edu => (
                  <div key={edu.id} className="text-xs">
                    <p className="font-bold text-gray-900">{edu.degree}</p>
                    <p className="text-slate-600">{edu.institution}, {edu.location}</p>
                    <p className="text-slate-500">{edu.startDate} – {edu.endDate}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {certifications.length > 0 && (
            <div>
              <h2 className="text-xs font-bold uppercase tracking-widest text-slate-800 mb-2 pb-1 border-b-2" style={{ borderColor: primaryColor }}>
                Certifications
              </h2>
              <div className="space-y-2">
                {certifications.map(cert => (
                  <div key={cert.id} className="text-xs">
                    <p className="font-bold text-gray-900">{cert.title}</p>
                    <p className="text-slate-600">{cert.issuer} ({cert.date})</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { ResumeData } from '../../../types/resume';
import { QrCode } from '../../common/QrCode';

interface TemplateProps {
  data: ResumeData;
}

export const TechMinimalist: React.FC<TemplateProps> = ({ data }) => {
  const { personalInfo, education, experience, projects, skills, certifications, style } = data;
  const primaryColor = style.primaryColor || '#4f46e5'; // Indigo

  return (
    <div className="w-full bg-white text-gray-800 font-mono text-xs max-w-[850px] mx-auto p-8 shadow-sm print:shadow-none print:p-0">
      {/* Code Header */}
      <div className="bg-slate-900 text-slate-100 p-6 rounded-lg mb-6 border border-slate-800">
        <div className="flex justify-between items-start">
          <div>
            <div className="text-emerald-400 font-bold text-xs mb-1">// {personalInfo.jobTitle || 'Full Stack Engineer'}</div>
            <h1 className="text-2xl font-bold tracking-tight text-white">{`<${personalInfo.fullName || 'Alex Morgan'} />`}</h1>
            <p className="text-slate-400 text-[11px] mt-1">{personalInfo.address}</p>
          </div>
          {style.showQrCode && personalInfo.portfolio && (
            <div className="bg-white p-1 rounded">
              <QrCode value={personalInfo.portfolio} size={48} color="#0f172a" />
            </div>
          )}
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800 flex flex-wrap gap-4 text-[11px] text-indigo-300">
          {personalInfo.email && <span>email: "{personalInfo.email}"</span>}
          {personalInfo.github && (
            <a href={personalInfo.github} target="_blank" rel="noreferrer" className="underline hover:text-white">
              github: "{personalInfo.github.replace('https://github.com/', '')}"
            </a>
          )}
          {personalInfo.linkedin && (
            <a href={personalInfo.linkedin} target="_blank" rel="noreferrer" className="underline hover:text-white">
              linkedin
            </a>
          )}
        </div>
      </div>

      {/* Summary */}
      {personalInfo.summary && (
        <div className="mb-6 font-sans">
          <div className="text-[11px] font-mono font-bold text-indigo-600 mb-1" style={{ color: primaryColor }}>
            const summary =
          </div>
          <p className="text-gray-700 bg-slate-50 p-3 rounded border border-slate-200 text-xs leading-relaxed">
            "{personalInfo.summary}"
          </p>
        </div>
      )}

      {/* Experience */}
      {experience.length > 0 && (
        <div className="mb-6 font-sans">
          <div className="text-[11px] font-mono font-bold text-indigo-600 mb-2" style={{ color: primaryColor }}>
            function getExperience() {`{`}
          </div>
          <div className="space-y-4 pl-3 border-l-2 border-indigo-200">
            {experience.map(exp => (
              <div key={exp.id}>
                <div className="flex justify-between items-baseline font-mono text-xs">
                  <span className="font-bold text-gray-900">{exp.jobTitle} @ {exp.company}</span>
                  <span className="text-gray-500">{exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate}</span>
                </div>
                <div className="text-gray-700 text-xs whitespace-pre-line mt-1">
                  {exp.description}
                </div>
              </div>
            ))}
          </div>
          <div className="text-[11px] font-mono font-bold text-indigo-600 mt-2" style={{ color: primaryColor }}>
            {`}`}
          </div>
        </div>
      )}

      {/* Tech Stack */}
      {skills.technical.length > 0 && (
        <div className="mb-6">
          <div className="text-[11px] font-mono font-bold text-indigo-600 mb-2" style={{ color: primaryColor }}>
            const techStack = [
          </div>
          <div className="flex flex-wrap gap-1.5 pl-3">
            {skills.technical.map((skill, idx) => (
              <span key={idx} className="bg-slate-900 text-slate-100 text-[10px] px-2 py-0.5 rounded font-mono">
                "{skill}"{idx < skills.technical.length - 1 ? ',' : ''}
              </span>
            ))}
          </div>
          <div className="text-[11px] font-mono font-bold text-indigo-600 mt-2" style={{ color: primaryColor }}>
            ];
          </div>
        </div>
      )}

      {/* Projects */}
      {projects.length > 0 && (
        <div className="mb-6 font-sans">
          <div className="text-[11px] font-mono font-bold text-indigo-600 mb-2" style={{ color: primaryColor }}>
            const keyProjects = [
          </div>
          <div className="space-y-3 pl-3">
            {projects.map(proj => (
              <div key={proj.id} className="p-3 bg-gray-50 rounded border border-gray-200">
                <div className="flex justify-between items-start font-mono text-xs">
                  <span className="font-bold text-gray-900">{proj.title}</span>
                  <div className="flex gap-2">
                    {proj.githubUrl && <a href={proj.githubUrl} target="_blank" rel="noreferrer" className="text-indigo-600 underline">[repo]</a>}
                    {proj.liveUrl && <a href={proj.liveUrl} target="_blank" rel="noreferrer" className="text-emerald-600 underline">[demo]</a>}
                  </div>
                </div>
                <p className="text-xs text-gray-700 mt-1">{proj.description}</p>
              </div>
            ))}
          </div>
          <div className="text-[11px] font-mono font-bold text-indigo-600 mt-2" style={{ color: primaryColor }}>
            ];
          </div>
        </div>
      )}

      {/* Education */}
      {education.length > 0 && (
        <div className="font-sans">
          <div className="text-[11px] font-mono font-bold text-indigo-600 mb-1" style={{ color: primaryColor }}>
            // Education
          </div>
          {education.map(edu => (
            <div key={edu.id} className="text-xs text-gray-800">
              <span className="font-bold">{edu.degree}</span> — {edu.institution} ({edu.startDate} - {edu.endDate})
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

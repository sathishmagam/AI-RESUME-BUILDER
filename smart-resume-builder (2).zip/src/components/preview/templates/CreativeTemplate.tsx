import React from 'react';
import { ResumeData } from '../../../types/resume';
import { QrCode } from '../../common/QrCode';

interface TemplateProps {
  data: ResumeData;
}

export const CreativeTemplate: React.FC<TemplateProps> = ({ data }) => {
  const { personalInfo, education, experience, projects, skills, certifications, style } = data;
  const primaryColor = style.primaryColor || '#9333ea'; // Purple

  return (
    <div className="w-full bg-white text-gray-800 font-sans text-xs max-w-[850px] mx-auto shadow-sm print:shadow-none print:p-0">
      {/* Creative Header with Gradient background bar */}
      <div className="p-8 text-white rounded-b-2xl shadow-md mb-6" style={{ backgroundColor: primaryColor }}>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div className="flex items-center gap-4">
            {style.showPhoto && personalInfo.photoUrl && (
              <img
                src={personalInfo.photoUrl}
                alt={personalInfo.fullName}
                className="w-20 h-20 rounded-full object-cover border-4 border-white/20 shadow"
              />
            )}
            <div>
              <h1 className="text-3xl font-black tracking-tight">{personalInfo.fullName || 'Alex Morgan'}</h1>
              <span className="inline-block px-3 py-0.5 mt-1 bg-white/20 rounded-full text-xs font-semibold backdrop-blur-xs">
                {personalInfo.jobTitle || 'Creative Director / Developer'}
              </span>
            </div>
          </div>

          <div className="mt-4 sm:mt-0 text-left sm:text-right text-xs space-y-1 text-white/90 font-medium">
            {personalInfo.email && <div>✉️ {personalInfo.email}</div>}
            {personalInfo.phone && <div>📞 {personalInfo.phone}</div>}
            {personalInfo.address && <div>📍 {personalInfo.address}</div>}
            {personalInfo.portfolio && (
              <div className="pt-1">
                <a href={personalInfo.portfolio} target="_blank" rel="noreferrer" className="underline font-bold hover:text-white">
                  {personalInfo.portfolio.replace('https://', '')}
                </a>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="px-8 pb-8 space-y-6">
        {/* Summary */}
        {personalInfo.summary && (
          <div className="p-4 bg-purple-50 rounded-xl border border-purple-100 text-gray-700 leading-relaxed font-medium">
            <span className="font-bold block mb-1" style={{ color: primaryColor }}>🎨 About Me</span>
            {personalInfo.summary}
          </div>
        )}

        {/* Grid layout */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Main Work Experience */}
          <div className="md:col-span-2 space-y-6">
            {experience.length > 0 && (
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2" style={{ color: primaryColor }}>
                  ✨ Work Experience
                </h2>
                <div className="space-y-4">
                  {experience.map(exp => (
                    <div key={exp.id} className="p-4 rounded-xl bg-gray-50 border border-gray-100 shadow-2xs">
                      <div className="flex justify-between items-start mb-1">
                        <h3 className="font-bold text-gray-900 text-sm">{exp.jobTitle}</h3>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full text-white" style={{ backgroundColor: primaryColor }}>
                          {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate}
                        </span>
                      </div>
                      <p className="text-xs font-semibold text-gray-600 mb-2">{exp.company} • {exp.location}</p>
                      <p className="text-xs text-gray-700 whitespace-pre-line leading-relaxed">{exp.description}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Projects */}
            {projects.length > 0 && (
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2" style={{ color: primaryColor }}>
                  🚀 Showcase Projects
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {projects.map(p => (
                    <div key={p.id} className="p-3 bg-white rounded-xl border-2 border-gray-100 hover:border-purple-200 transition-colors">
                      <div className="font-bold text-gray-900 mb-1">{p.title}</div>
                      <p className="text-gray-600 text-[11px] mb-2">{p.description}</p>
                      {p.technologies && (
                        <div className="flex flex-wrap gap-1">
                          {p.technologies.map((t, idx) => (
                            <span key={idx} className="text-[9px] px-1.5 py-0.5 rounded bg-purple-50 text-purple-700 font-bold">
                              {t}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Skills Pills */}
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2" style={{ color: primaryColor }}>
                💡 Superpowers
              </h2>
              <div className="flex flex-wrap gap-1.5">
                {skills.technical.map((s, idx) => (
                  <span
                    key={idx}
                    className="text-[11px] px-2.5 py-1 rounded-full font-bold text-white shadow-xs"
                    style={{ backgroundColor: primaryColor }}
                  >
                    {s}
                  </span>
                ))}
              </div>
            </div>

            {/* Education */}
            {education.length > 0 && (
              <div>
                <h2 className="text-sm font-bold uppercase tracking-wider mb-2 flex items-center gap-2" style={{ color: primaryColor }}>
                  🎓 Education
                </h2>
                <div className="space-y-2">
                  {education.map(e => (
                    <div key={e.id} className="p-3 bg-gray-50 rounded-lg">
                      <p className="font-bold text-gray-900">{e.degree}</p>
                      <p className="text-gray-600">{e.institution}</p>
                      <p className="text-[10px] text-gray-400">{e.startDate} – {e.endDate}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* QR Code */}
            {style.showQrCode && personalInfo.portfolio && (
              <div className="p-4 bg-purple-50 rounded-xl flex flex-col items-center text-center">
                <QrCode value={personalInfo.portfolio} size={60} color={primaryColor} />
                <span className="text-[10px] font-bold text-purple-800 mt-1">Scan My Portfolio</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

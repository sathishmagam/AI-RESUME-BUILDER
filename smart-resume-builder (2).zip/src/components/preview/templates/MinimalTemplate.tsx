import React from 'react';
import { ResumeData } from '../../../types/resume';

interface TemplateProps {
  data: ResumeData;
}

export const MinimalTemplate: React.FC<TemplateProps> = ({ data }) => {
  const { personalInfo, education, experience, projects, skills, style } = data;
  const primaryColor = style.primaryColor || '#059669'; // Emerald

  return (
    <div className="w-full bg-white text-gray-800 font-sans text-xs leading-relaxed max-w-[850px] mx-auto p-10 shadow-sm print:shadow-none print:p-0">
      {/* Minimal Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-light tracking-tight text-gray-900 mb-1">
          {personalInfo.fullName || 'Alex Morgan'}
        </h1>
        <p className="text-sm font-medium tracking-wide uppercase text-emerald-600 mb-3" style={{ color: primaryColor }}>
          {personalInfo.jobTitle || 'Software Engineer'}
        </p>
        <div className="flex flex-wrap gap-x-4 gap-y-1 text-gray-500 font-mono text-[11px]">
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.phone && <span>{personalInfo.phone}</span>}
          {personalInfo.address && <span>{personalInfo.address}</span>}
          {personalInfo.portfolio && (
            <a href={personalInfo.portfolio} target="_blank" rel="noreferrer" className="underline hover:text-black">
              {personalInfo.portfolio}
            </a>
          )}
        </div>
      </div>

      <div className="space-y-6">
        {/* About */}
        {personalInfo.summary && (
          <div>
            <h2 className="text-[10px] font-bold tracking-widest uppercase text-gray-400 mb-2">01 / ABOUT</h2>
            <p className="text-gray-700 leading-normal">{personalInfo.summary}</p>
          </div>
        )}

        {/* Experience */}
        {experience.length > 0 && (
          <div>
            <h2 className="text-[10px] font-bold tracking-widest uppercase text-gray-400 mb-3">02 / EXPERIENCE</h2>
            <div className="space-y-4">
              {experience.map(exp => (
                <div key={exp.id} className="grid grid-cols-1 sm:grid-cols-4 gap-2">
                  <div className="sm:col-span-1 text-gray-400 font-mono text-[11px]">
                    {exp.startDate} – {exp.isCurrent ? 'NOW' : exp.endDate}
                  </div>
                  <div className="sm:col-span-3">
                    <h3 className="font-bold text-gray-900 text-sm">{exp.jobTitle}</h3>
                    <p className="text-gray-600 font-medium mb-1">{exp.company}, {exp.location}</p>
                    <p className="text-gray-700 whitespace-pre-line leading-relaxed">{exp.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects */}
        {projects.length > 0 && (
          <div>
            <h2 className="text-[10px] font-bold tracking-widest uppercase text-gray-400 mb-3">03 / PROJECTS</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {projects.map(proj => (
                <div key={proj.id} className="border border-gray-100 p-3 rounded-md">
                  <div className="font-bold text-gray-900 mb-1">{proj.title}</div>
                  <p className="text-gray-600 text-[11px] mb-2">{proj.description}</p>
                  {proj.technologies && (
                    <div className="text-[10px] font-mono text-gray-400">{proj.technologies.join(' • ')}</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education & Skills */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2 border-t border-gray-100">
          {education.length > 0 && (
            <div>
              <h2 className="text-[10px] font-bold tracking-widest uppercase text-gray-400 mb-2">04 / EDUCATION</h2>
              {education.map(edu => (
                <div key={edu.id} className="mb-2">
                  <div className="font-bold text-gray-900">{edu.degree}</div>
                  <div className="text-gray-600">{edu.institution} ({edu.startDate} – {edu.endDate})</div>
                </div>
              ))}
            </div>
          )}

          {skills.technical.length > 0 && (
            <div>
              <h2 className="text-[10px] font-bold tracking-widest uppercase text-gray-400 mb-2">05 / SKILLS</h2>
              <p className="text-gray-700 leading-relaxed font-mono text-[11px]">
                {skills.technical.join(' • ')}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

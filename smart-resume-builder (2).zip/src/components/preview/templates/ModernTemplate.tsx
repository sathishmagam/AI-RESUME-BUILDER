import React from 'react';
import { ResumeData } from '../../../types/resume';
import { QrCode } from '../../common/QrCode';

interface TemplateProps {
  data: ResumeData;
}

export const ModernTemplate: React.FC<TemplateProps> = ({ data }) => {
  const { personalInfo, education, experience, projects, skills, certifications, achievements, references, style } = data;
  const primaryColor = style.primaryColor || '#2563eb';

  return (
    <div className="w-full bg-white text-gray-800 p-8 font-sans text-sm max-w-[850px] mx-auto shadow-sm print:shadow-none print:p-0">
      {/* Top Banner Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start pb-6 border-b-2 mb-6" style={{ borderColor: primaryColor }}>
        <div className="flex items-center gap-4">
          {style.showPhoto && personalInfo.photoUrl && (
            <img
              src={personalInfo.photoUrl}
              alt={personalInfo.fullName}
              className="w-20 h-20 rounded-full object-cover border-2 shadow-sm"
              style={{ borderColor: primaryColor }}
            />
          )}
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gray-900">
              {personalInfo.fullName || 'Alex Morgan'}
            </h1>
            <p className="text-base font-medium mt-0.5" style={{ color: primaryColor }}>
              {personalInfo.jobTitle || 'Full Stack Engineer'}
            </p>
          </div>
        </div>

        <div className="mt-4 sm:mt-0 flex flex-col items-start sm:items-end text-xs text-gray-600 space-y-1">
          {personalInfo.email && <span>✉️ {personalInfo.email}</span>}
          {personalInfo.phone && <span>📞 {personalInfo.phone}</span>}
          {personalInfo.address && <span>📍 {personalInfo.address}</span>}
          <div className="flex gap-2 font-medium mt-1">
            {personalInfo.linkedin && (
              <a href={personalInfo.linkedin} target="_blank" rel="noreferrer" className="hover:underline" style={{ color: primaryColor }}>
                LinkedIn
              </a>
            )}
            {personalInfo.github && (
              <a href={personalInfo.github} target="_blank" rel="noreferrer" className="hover:underline" style={{ color: primaryColor }}>
                GitHub
              </a>
            )}
            {personalInfo.portfolio && (
              <a href={personalInfo.portfolio} target="_blank" rel="noreferrer" className="hover:underline" style={{ color: primaryColor }}>
                Portfolio
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Main Grid: 2 Columns */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column (Main Content - 2 cols) */}
        <div className="md:col-span-2 space-y-6">
          {/* Summary */}
          {personalInfo.summary && (
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider mb-2 flex items-center gap-2" style={{ color: primaryColor }}>
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: primaryColor }} />
                Professional Summary
              </h2>
              <p className="text-xs text-gray-700 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
                {personalInfo.summary}
              </p>
            </div>
          )}

          {/* Work Experience */}
          {experience.length > 0 && (
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2" style={{ color: primaryColor }}>
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: primaryColor }} />
                Work Experience
              </h2>
              <div className="space-y-4">
                {experience.map(exp => (
                  <div key={exp.id} className="relative pl-4 border-l-2" style={{ borderColor: `${primaryColor}40` }}>
                    <div
                      className="absolute -left-[5px] top-1.5 w-2 h-2 rounded-full"
                      style={{ backgroundColor: primaryColor }}
                    />
                    <div className="flex justify-between items-baseline">
                      <h3 className="font-bold text-gray-900 text-sm">{exp.jobTitle}</h3>
                      <span className="text-[11px] font-medium text-gray-500">
                        {exp.startDate} – {exp.isCurrent ? 'Present' : exp.endDate}
                      </span>
                    </div>
                    <div className="text-xs font-medium text-gray-600 mb-1.5">
                      {exp.company} • {exp.location}
                    </div>
                    <p className="text-xs text-gray-700 whitespace-pre-line leading-relaxed">
                      {exp.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Key Projects */}
          {projects.length > 0 && (
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2" style={{ color: primaryColor }}>
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: primaryColor }} />
                Featured Projects
              </h2>
              <div className="space-y-3">
                {projects.map(proj => (
                  <div key={proj.id} className="p-3 bg-gray-50 rounded-lg border border-gray-100">
                    <div className="flex justify-between items-start mb-1">
                      <div>
                        <span className="font-bold text-gray-900 text-xs">{proj.title}</span>
                        {proj.subtitle && <span className="text-[11px] text-gray-500 ml-1.5">({proj.subtitle})</span>}
                      </div>
                      <div className="flex gap-2 text-[11px]">
                        {proj.githubUrl && <a href={proj.githubUrl} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">Code</a>}
                        {proj.liveUrl && <a href={proj.liveUrl} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline">Live</a>}
                      </div>
                    </div>
                    <p className="text-[11px] text-gray-700 mb-2">{proj.description}</p>
                    {proj.technologies && proj.technologies.length > 0 && (
                      <div className="flex flex-wrap gap-1">
                        {proj.technologies.map((t, idx) => (
                          <span key={idx} className="text-[10px] px-1.5 py-0.5 rounded bg-white text-gray-700 border border-gray-200">
                            {t}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right Sidebar Column */}
        <div className="space-y-6">
          {/* Skills */}
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2" style={{ color: primaryColor }}>
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: primaryColor }} />
              Skills & Tech
            </h2>

            {skills.technical.length > 0 && (
              <div className="mb-3">
                <span className="text-xs font-semibold text-gray-700 block mb-1">Technical Skills</span>
                <div className="flex flex-wrap gap-1">
                  {skills.technical.map((s, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] px-2 py-0.5 rounded-md font-medium text-white shadow-xs"
                      style={{ backgroundColor: primaryColor }}
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {skills.soft.length > 0 && (
              <div className="mb-3">
                <span className="text-xs font-semibold text-gray-700 block mb-1">Soft Skills</span>
                <div className="flex flex-wrap gap-1">
                  {skills.soft.map((s, idx) => (
                    <span key={idx} className="text-[10px] px-2 py-0.5 rounded-md bg-gray-100 text-gray-700 font-medium">
                      {s}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {skills.languages.length > 0 && (
              <div>
                <span className="text-xs font-semibold text-gray-700 block mb-1">Languages</span>
                <div className="text-xs text-gray-600 space-y-0.5">
                  {skills.languages.map((l, idx) => (
                    <div key={idx} className="flex justify-between text-[11px]">
                      <span>{l.language}</span>
                      <span className="text-gray-400">{l.proficiency}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Education */}
          {education.length > 0 && (
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2" style={{ color: primaryColor }}>
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: primaryColor }} />
                Education
              </h2>
              <div className="space-y-3">
                {education.map(edu => (
                  <div key={edu.id} className="text-xs">
                    <p className="font-bold text-gray-900">{edu.degree}</p>
                    <p className="text-gray-600">{edu.institution}</p>
                    <p className="text-[11px] text-gray-400">{edu.startDate} – {edu.endDate} {edu.grade ? `| ${edu.grade}` : ''}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Certifications */}
          {certifications.length > 0 && (
            <div>
              <h2 className="text-sm font-bold uppercase tracking-wider mb-2 flex items-center gap-2" style={{ color: primaryColor }}>
                <span className="w-2 h-2 rounded-full" style={{ backgroundColor: primaryColor }} />
                Certifications
              </h2>
              <div className="space-y-2 text-xs">
                {certifications.map(c => (
                  <div key={c.id}>
                    <p className="font-semibold text-gray-800">{c.title}</p>
                    <p className="text-[11px] text-gray-500">{c.issuer} ({c.date})</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* QR Code */}
          {style.showQrCode && personalInfo.portfolio && (
            <div className="pt-2 flex flex-col items-center justify-center text-center">
              <QrCode value={personalInfo.portfolio} size={64} color={primaryColor} />
              <span className="text-[10px] text-gray-400 mt-1">Scan for Portfolio</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

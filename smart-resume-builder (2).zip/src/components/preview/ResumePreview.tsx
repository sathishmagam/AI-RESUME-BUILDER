import React, { useState } from 'react';
import { ResumeData, TemplateId } from '../../types/resume';
import { TEMPLATE_METADATA } from '../../data/initialData';
import { ClassicTemplate } from './templates/ClassicTemplate';
import { ModernTemplate } from './templates/ModernTemplate';
import { ExecutiveTemplate } from './templates/ExecutiveTemplate';
import { MinimalTemplate } from './templates/MinimalTemplate';
import { CreativeTemplate } from './templates/CreativeTemplate';
import { TechMinimalist } from './templates/TechMinimalist';
import { DownloadModal } from '../common/DownloadModal';
import { Printer, Download, ZoomIn, ZoomOut, Palette, Layout, Sparkles, Share2, FileDown } from 'lucide-react';

interface ResumePreviewProps {
  data: ResumeData;
  onChangeStyle?: (newStyle: Partial<ResumeData['style']>) => void;
  onOpenAtsModal?: () => void;
  onOpenCoverLetterModal?: () => void;
}

const COLOR_PRESETS = [
  { name: 'Royal Blue', hex: '#2563eb' },
  { name: 'Navy Slate', hex: '#0f172a' },
  { name: 'Emerald Green', hex: '#059669' },
  { name: 'Deep Purple', hex: '#9333ea' },
  { name: 'Classic Burgundy', hex: '#881337' },
  { name: 'Teal Cyan', hex: '#0f766e' },
  { name: 'Charcoal Dark', hex: '#334155' },
];

export const ResumePreview: React.FC<ResumePreviewProps> = ({
  data,
  onChangeStyle,
  onOpenAtsModal,
  onOpenCoverLetterModal,
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(100);
  const [copiedLink, setCopiedLink] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  const activeTemplate = data.style.template || 'modern';

  const handleShare = () => {
    const fakeUrl = `${window.location.origin}/#share-${data.id}`;
    navigator.clipboard.writeText(fakeUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const renderTemplateComponent = () => {
    switch (activeTemplate) {
      case 'classic':
        return <ClassicTemplate data={data} />;
      case 'executive':
        return <ExecutiveTemplate data={data} />;
      case 'minimal':
        return <MinimalTemplate data={data} />;
      case 'creative':
        return <CreativeTemplate data={data} />;
      case 'tech':
        return <TechMinimalist data={data} />;
      case 'modern':
      default:
        return <ModernTemplate data={data} />;
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-100 dark:bg-slate-900 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800">
      {/* Top Preview Controls Bar (Hidden during Print) */}
      <div className="p-3 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-2 print:hidden z-10">
        {/* Left: Template Selector & Colors */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Template Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 dark:bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <Layout className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <select
              value={activeTemplate}
              onChange={e => onChangeStyle?.({ template: e.target.value as TemplateId })}
              className="bg-transparent text-xs font-semibold text-slate-800 dark:text-slate-100 focus:outline-none cursor-pointer"
            >
              {TEMPLATE_METADATA.map(tm => (
                <option key={tm.id} value={tm.id} className="dark:bg-slate-800">
                  {tm.name} ({tm.badge})
                </option>
              ))}
            </select>
          </div>

          {/* Color Palette Picker */}
          <div className="flex items-center gap-1 bg-slate-50 dark:bg-slate-900 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700">
            <Palette className="w-4 h-4 text-slate-500 mr-1" />
            {COLOR_PRESETS.map(c => (
              <button
                key={c.hex}
                onClick={() => onChangeStyle?.({ primaryColor: c.hex })}
                title={c.name}
                className={`w-5 h-5 rounded-full transition-transform hover:scale-110 ${
                  data.style.primaryColor === c.hex ? 'ring-2 ring-blue-500 ring-offset-1 dark:ring-offset-slate-900' : ''
                }`}
                style={{ backgroundColor: c.hex }}
              />
            ))}
          </div>
        </div>

        {/* Right: Actions (Zoom, Download Document, ATS, Share) */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Zoom controls */}
          <div className="flex items-center bg-slate-50 dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700 px-2 py-1">
            <button
              onClick={() => setZoomLevel(prev => Math.max(70, prev - 10))}
              className="p-1 text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white"
              title="Zoom Out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-xs font-mono px-1.5 text-slate-600 dark:text-slate-300">{zoomLevel}%</span>
            <button
              onClick={() => setZoomLevel(prev => Math.min(130, prev + 10))}
              className="p-1 text-slate-600 hover:text-slate-900 dark:text-slate-300 dark:hover:text-white"
              title="Zoom In"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* ATS Score Launcher */}
          {onOpenAtsModal && (
            <button
              onClick={onOpenAtsModal}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>ATS Score ({data.atsScore || 88}%)</span>
            </button>
          )}

          {/* Cover Letter Modal Launcher */}
          {onOpenCoverLetterModal && (
            <button
              onClick={onOpenCoverLetterModal}
              className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <span>Cover Letter</span>
            </button>
          )}

          {/* Share */}
          <button
            onClick={handleShare}
            className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs font-medium flex items-center gap-1"
            title="Share Resume Link"
          >
            <Share2 className="w-3.5 h-3.5" />
            {copiedLink ? <span className="text-emerald-600 dark:text-emerald-400 font-bold">Copied!</span> : null}
          </button>

          {/* Main Download Document Button */}
          <button
            onClick={() => setIsDownloadModalOpen(true)}
            className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-md active:scale-95 cursor-pointer"
          >
            <FileDown className="w-4 h-4" />
            <span>Download Document</span>
          </button>
        </div>
      </div>

      {/* Main Resume Canvas Container */}
      <div className="flex-1 overflow-auto p-4 sm:p-8 flex justify-center items-start print:p-0 print:overflow-visible">
        <div
          id="printable-resume"
          className="transition-transform origin-top duration-200 print:transform-none"
          style={{ transform: `scale(${zoomLevel / 100})` }}
        >
          {renderTemplateComponent()}
        </div>
      </div>

      {/* Download Options Modal */}
      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        data={data}
      />
    </div>
  );
};


import React, { useState } from 'react';
import { TEMPLATE_METADATA } from '../../data/initialData';
import { SAMPLE_RESUMES } from '../../data/initialData';
import { ClassicTemplate } from '../preview/templates/ClassicTemplate';
import { ModernTemplate } from '../preview/templates/ModernTemplate';
import { ExecutiveTemplate } from '../preview/templates/ExecutiveTemplate';
import { MinimalTemplate } from '../preview/templates/MinimalTemplate';
import { CreativeTemplate } from '../preview/templates/CreativeTemplate';
import { TechMinimalist } from '../preview/templates/TechMinimalist';
import { Layout, Sparkles, Check, ArrowRight } from 'lucide-react';

interface TemplatesViewProps {
  onSelectTemplate: (templateId: string) => void;
}

export const TemplatesView: React.FC<TemplatesViewProps> = ({ onSelectTemplate }) => {
  const [activeTemplateId, setActiveTemplateId] = useState('modern');
  const sampleData = SAMPLE_RESUMES[0];

  const renderTemplatePreview = () => {
    const dataWithTemplate = {
      ...sampleData,
      style: { ...sampleData.style, template: activeTemplateId as any },
    };

    switch (activeTemplateId) {
      case 'classic':
        return <ClassicTemplate data={dataWithTemplate} />;
      case 'executive':
        return <ExecutiveTemplate data={dataWithTemplate} />;
      case 'minimal':
        return <MinimalTemplate data={dataWithTemplate} />;
      case 'creative':
        return <CreativeTemplate data={dataWithTemplate} />;
      case 'tech':
        return <TechMinimalist data={dataWithTemplate} />;
      case 'modern':
      default:
        return <ModernTemplate data={dataWithTemplate} />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 text-xs font-bold">
          <Layout className="w-3.5 h-3.5" />
          <span>Professional Resume Templates</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
          Choose Your Perfect Resume Design
        </h1>
        <p className="text-slate-600 dark:text-slate-400 text-xs sm:text-sm">
          All templates are 100% ATS-ready, highly customizable, and designed to pass recruiter screeners.
        </p>
      </div>

      {/* Main Grid: Template Cards List & Live Interactive Stage */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left List of Templates */}
        <div className="lg:col-span-5 space-y-3">
          {TEMPLATE_METADATA.map(tm => {
            const isSelected = activeTemplateId === tm.id;
            return (
              <div
                key={tm.id}
                onClick={() => setActiveTemplateId(tm.id)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-blue-50/80 dark:bg-slate-800 border-blue-500 shadow-md ring-2 ring-blue-500/20'
                    : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-blue-300'
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    {tm.name}
                    {isSelected && <Check className="w-4 h-4 text-blue-600" />}
                  </h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                    {tm.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed mb-3">
                  {tm.description}
                </p>

                <button
                  onClick={e => {
                    e.stopPropagation();
                    onSelectTemplate(tm.id);
                  }}
                  className="px-4 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs flex items-center gap-1 shadow-2xs"
                >
                  <span>Use This Template</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Right Live Stage Preview */}
        <div className="lg:col-span-7 bg-slate-200 dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-300 dark:border-slate-800 flex flex-col items-center shadow-inner overflow-auto max-h-[800px]">
          <div className="w-full max-w-[750px] transform scale-90 sm:scale-100 origin-top">
            {renderTemplatePreview()}
          </div>
        </div>
      </div>
    </div>
  );
};

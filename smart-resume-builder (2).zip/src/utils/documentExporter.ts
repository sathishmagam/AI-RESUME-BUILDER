import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { ResumeData } from '../types/resume';

/**
 * Triggers high-fidelity PDF download using html2canvas & jsPDF with native window.print fallback.
 * Solves blank PDF issues by resetting scale transforms, waiting for fonts/images,
 * and accurately slicing multi-page A4 canvas nodes.
 */
export const downloadAsPdf = async (
  data: ResumeData,
  elementId: string = 'printable-resume'
): Promise<{ success: boolean; method: 'jsPDF' | 'print'; message?: string }> => {
  console.log('[DocumentExporter] Initiating PDF Export...', {
    fullName: data?.personalInfo?.fullName,
    elementId,
    timestamp: new Date().toISOString(),
  });

  if (!data || !data.personalInfo) {
    console.error('[DocumentExporter] Missing or invalid resume data provided to PDF exporter.');
    throw new Error('Invalid resume data. Please ensure personal details are provided.');
  }

  const targetElement = document.getElementById(elementId);
  if (!targetElement) {
    console.warn(`[DocumentExporter] Element #${elementId} not found in DOM. Falling back to native print.`);
    window.print();
    return { success: true, method: 'print' };
  }

  // Preserve original DOM element styles
  const originalTransform = targetElement.style.transform;
  const originalTransition = targetElement.style.transition;
  const originalWidth = targetElement.style.width;

  try {
    // Step 1: Prepare DOM node for 1:1 scale capturing
    targetElement.style.transform = 'none';
    targetElement.style.transition = 'none';

    // Step 2: Ensure fonts and images are fully rendered
    if ('fonts' in document) {
      await document.fonts.ready;
    }
    await new Promise(resolve => setTimeout(resolve, 150));

    // Step 3: Render element to HTML Canvas
    console.log('[DocumentExporter] Capturing DOM canvas via html2canvas...');
    const canvas = await html2canvas(targetElement, {
      scale: 2, // High resolution (300 DPI output)
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      logging: false,
      windowWidth: 800, // Normalized printable width
    });

    console.log('[DocumentExporter] Canvas captured successfully.', {
      width: canvas.width,
      height: canvas.height,
    });

    if (canvas.width === 0 || canvas.height === 0) {
      throw new Error('Canvas width or height calculated as 0px.');
    }

    // Step 4: Convert Canvas to PDF via jsPDF
    const imgData = canvas.toDataURL('image/jpeg', 0.98);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pdfWidth = pdf.internal.pageSize.getWidth(); // 210mm
    const pdfHeight = pdf.internal.pageSize.getHeight(); // 297mm

    const imgWidth = pdfWidth;
    const imgHeight = (canvas.height * pdfWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 0;

    // First page
    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
    heightLeft -= pdfHeight;

    // Multi-page handling
    while (heightLeft > 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pdfHeight;
    }

    const fileName = `${(data.personalInfo.fullName || 'Resume').replace(/\s+/g, '_')}_Resume.pdf`;
    pdf.save(fileName);

    console.log(`[DocumentExporter] PDF successfully generated and saved as "${fileName}".`);
    return { success: true, method: 'jsPDF' };
  } catch (error) {
    console.error('[DocumentExporter] html2canvas/jsPDF generation failed. Fallback to window.print():', error);
    
    // Fallback to browser print dialog
    window.print();
    return {
      success: true,
      method: 'print',
      message: 'Downloaded via browser print fallback.',
    };
  } finally {
    // Restore original DOM element styles
    if (targetElement) {
      targetElement.style.transform = originalTransform;
      targetElement.style.transition = originalTransition;
      targetElement.style.width = originalWidth;
    }
  }
};

/**
 * Helper to trigger browser blob download
 */
const triggerBlobDownload = (blob: Blob, filename: string): void => {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
};

/**
 * Generates and downloads a clean, human-readable Plain Text (.txt) document.
 */
export const downloadAsPlainText = (data: ResumeData): void => {
  console.log('[DocumentExporter] Generating Plain Text document...', { title: data?.title });

  if (!data || !data.personalInfo) {
    console.error('[DocumentExporter] Invalid resume data provided to Plain Text exporter.');
    throw new Error('Resume data is missing.');
  }

  const { personalInfo, experience, education, projects, skills, certifications, achievements, interests, references, customSections } = data;
  const lines: string[] = [];

  // Header & Personal Contact Info
  if (personalInfo.fullName) lines.push(personalInfo.fullName.toUpperCase());
  if (personalInfo.jobTitle) lines.push(personalInfo.jobTitle);
  lines.push('');

  const contacts = [
    personalInfo.email,
    personalInfo.phone,
    personalInfo.address,
    personalInfo.linkedin,
    personalInfo.github,
    personalInfo.portfolio,
  ].filter(Boolean);

  if (contacts.length > 0) {
    lines.push(contacts.join(' | '));
    lines.push('');
  }

  // Professional Summary
  if (personalInfo.summary) {
    lines.push('================================================================');
    lines.push('PROFESSIONAL SUMMARY');
    lines.push('================================================================');
    lines.push(personalInfo.summary);
    lines.push('');
  }

  // Work Experience
  if (experience && experience.length > 0) {
    lines.push('================================================================');
    lines.push('WORK EXPERIENCE');
    lines.push('================================================================');
    experience.forEach(exp => {
      lines.push(`${exp.jobTitle || 'Role'} - ${exp.company || 'Company'} (${exp.startDate || ''} - ${exp.isCurrent ? 'Present' : exp.endDate || ''})`);
      if (exp.location) lines.push(`Location: ${exp.location}`);
      if (exp.description) {
        const expBullets = exp.description.split('\n').map(line => line.trim()).filter(Boolean);
        expBullets.forEach(bullet => {
          lines.push(`  • ${bullet.replace(/^[•\-\*]\s*/, '')}`);
        });
      }
      lines.push('');
    });
  }

  // Education
  if (education && education.length > 0) {
    lines.push('================================================================');
    lines.push('EDUCATION');
    lines.push('================================================================');
    education.forEach(edu => {
      lines.push(`${edu.degree || 'Degree'} - ${edu.institution || 'Institution'} (${edu.startDate || ''} - ${edu.endDate || ''})`);
      if (edu.location) lines.push(`Location: ${edu.location}`);
      if (edu.grade) lines.push(`GPA/Grade: ${edu.grade}`);
      if (edu.description) lines.push(`Details: ${edu.description}`);
      lines.push('');
    });
  }

  // Key Projects
  if (projects && projects.length > 0) {
    lines.push('================================================================');
    lines.push('KEY PROJECTS');
    lines.push('================================================================');
    projects.forEach(proj => {
      lines.push(`${proj.title || 'Project'}${proj.subtitle ? ` (${proj.subtitle})` : ''}`);
      if (proj.technologies && proj.technologies.length > 0) {
        lines.push(`Technologies: ${proj.technologies.join(', ')}`);
      }
      if (proj.liveUrl || proj.githubUrl) {
        lines.push(`Links: ${[proj.liveUrl, proj.githubUrl].filter(Boolean).join(' | ')}`);
      }
      if (proj.description) {
        const projBullets = proj.description.split('\n').map(l => l.trim()).filter(Boolean);
        projBullets.forEach(b => {
          lines.push(`  • ${b.replace(/^[•\-\*]\s*/, '')}`);
        });
      }
      lines.push('');
    });
  }

  // Skills
  const techSkills = skills?.technical || [];
  const softSkills = skills?.soft || [];
  const langSkills = skills?.languages || [];

  if (techSkills.length > 0 || softSkills.length > 0 || langSkills.length > 0) {
    lines.push('================================================================');
    lines.push('SKILLS & COMPETENCIES');
    lines.push('================================================================');
    if (techSkills.length > 0) lines.push(`Technical Skills: ${techSkills.join(', ')}`);
    if (softSkills.length > 0) lines.push(`Soft Skills: ${softSkills.join(', ')}`);
    if (langSkills.length > 0) {
      lines.push(`Languages: ${langSkills.map(l => `${l.language} (${l.proficiency})`).join(', ')}`);
    }
    lines.push('');
  }

  // Certifications
  if (certifications && certifications.length > 0) {
    lines.push('================================================================');
    lines.push('CERTIFICATIONS');
    lines.push('================================================================');
    certifications.forEach(cert => {
      lines.push(`• ${cert.title} - ${cert.issuer} (${cert.date})${cert.credentialId ? ` [ID: ${cert.credentialId}]` : ''}`);
    });
    lines.push('');
  }

  // Achievements
  if (achievements && achievements.length > 0) {
    lines.push('================================================================');
    lines.push('HONORS & ACHIEVEMENTS');
    lines.push('================================================================');
    achievements.forEach(ach => {
      lines.push(`• ${ach.title} - ${ach.organization} (${ach.date}): ${ach.description}`);
    });
    lines.push('');
  }

  // Interests
  if (interests && interests.length > 0) {
    lines.push('================================================================');
    lines.push('INTERESTS & ACTIVITIES');
    lines.push('================================================================');
    lines.push(interests.join(', '));
    lines.push('');
  }

  // References
  if (references && references.length > 0) {
    lines.push('================================================================');
    lines.push('REFERENCES');
    lines.push('================================================================');
    references.forEach(ref => {
      lines.push(`• ${ref.name} - ${ref.position} at ${ref.company} (Email: ${ref.email}, Phone: ${ref.phone})`);
    });
    lines.push('');
  }

  // Custom Sections
  if (customSections && customSections.length > 0) {
    customSections.forEach(sec => {
      lines.push('================================================================');
      lines.push(sec.title.toUpperCase());
      lines.push('================================================================');
      sec.items.forEach(item => {
        lines.push(`${item.title}${item.subtitle ? ` (${item.subtitle})` : ''}${item.date ? ` - ${item.date}` : ''}`);
        if (item.description) lines.push(`  ${item.description}`);
      });
      lines.push('');
    });
  }

  const content = lines.join('\n');
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const filename = `${(personalInfo.fullName || 'Resume').replace(/\s+/g, '_')}_Resume.txt`;
  triggerBlobDownload(blob, filename);
  console.log(`[DocumentExporter] Plain text document downloaded as "${filename}".`);
};

/**
 * Generates and downloads a Microsoft Word (.doc) document.
 * Uses formatted HTML layout with Word mime-type for full compatibility with MS Word & Google Docs.
 */
export const downloadAsWordDoc = (data: ResumeData): void => {
  console.log('[DocumentExporter] Generating Microsoft Word document...', { title: data?.title });

  if (!data || !data.personalInfo) {
    console.error('[DocumentExporter] Invalid resume data provided to Word exporter.');
    throw new Error('Resume data is missing.');
  }

  const { personalInfo, experience, education, projects, skills, certifications, achievements, interests, references, customSections, style } = data;
  const primaryColor = style?.primaryColor || '#2563eb';

  const htmlContent = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta charset="utf-8">
      <title>${personalInfo.fullName || 'Resume'}</title>
      <style>
        body {
          font-family: Arial, 'Helvetica Neue', sans-serif;
          font-size: 11pt;
          line-height: 1.4;
          color: #1e293b;
          margin: 0;
          padding: 24px;
        }
        h1 {
          font-size: 22pt;
          color: ${primaryColor};
          margin: 0 0 4px 0;
          padding: 0;
          text-transform: uppercase;
        }
        .subtitle {
          font-size: 13pt;
          color: #475569;
          font-weight: bold;
          margin-bottom: 8px;
        }
        .contact-info {
          font-size: 9.5pt;
          color: #64748b;
          border-bottom: 2px solid ${primaryColor};
          padding-bottom: 8px;
          margin-bottom: 16px;
        }
        .section-title {
          font-size: 12pt;
          font-weight: bold;
          color: ${primaryColor};
          text-transform: uppercase;
          border-bottom: 1.5px solid #cbd5e1;
          margin-top: 18px;
          margin-bottom: 8px;
          padding-bottom: 3px;
        }
        .item-title {
          font-size: 11pt;
          font-weight: bold;
          color: #0f172a;
        }
        .item-meta {
          font-size: 9.5pt;
          color: #64748b;
          font-style: italic;
        }
        ul {
          margin: 4px 0 12px 20px;
          padding: 0;
        }
        li {
          margin-bottom: 4px;
        }
      </style>
    </head>
    <body>
      <!-- Header -->
      <h1>${personalInfo.fullName || 'Your Name'}</h1>
      <div class="subtitle">${personalInfo.jobTitle || ''}</div>
      <div class="contact-info">
        ${[
          personalInfo.email,
          personalInfo.phone,
          personalInfo.address,
          personalInfo.linkedin,
          personalInfo.github,
          personalInfo.portfolio,
        ].filter(Boolean).join(' &nbsp;|&nbsp; ')}
      </div>

      <!-- Professional Summary -->
      ${personalInfo.summary ? `
        <div class="section-title">Professional Summary</div>
        <p style="margin-bottom: 12px;">${personalInfo.summary}</p>
      ` : ''}

      <!-- Work Experience -->
      ${experience && experience.length > 0 ? `
        <div class="section-title">Work Experience</div>
        ${experience.map(exp => `
          <div style="margin-bottom: 12px;">
            <table width="100%" cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td class="item-title" align="left">${exp.jobTitle || 'Position'} — ${exp.company || 'Company'}</td>
                <td class="item-meta" align="right">${exp.startDate || ''} - ${exp.isCurrent ? 'Present' : exp.endDate || ''}</td>
              </tr>
            </table>
            ${exp.location ? `<div class="item-meta">${exp.location}</div>` : ''}
            ${exp.description ? `
              <ul>
                ${exp.description.split('\n').filter(Boolean).map(line => `
                  <li>${line.replace(/^[•\-\*]\s*/, '')}</li>
                `).join('')}
              </ul>
            ` : ''}
          </div>
        `).join('')}
      ` : ''}

      <!-- Education -->
      ${education && education.length > 0 ? `
        <div class="section-title">Education</div>
        ${education.map(edu => `
          <div style="margin-bottom: 10px;">
            <table width="100%" cellpadding="0" cellspacing="0" border="0">
              <tr>
                <td class="item-title" align="left">${edu.degree || 'Degree'} — ${edu.institution || 'Institution'}</td>
                <td class="item-meta" align="right">${edu.startDate || ''} - ${edu.endDate || ''}</td>
              </tr>
            </table>
            ${edu.grade ? `<div class="item-meta">GPA/Grade: ${edu.grade}</div>` : ''}
            ${edu.description ? `<p style="margin: 4px 0;">${edu.description}</p>` : ''}
          </div>
        `).join('')}
      ` : ''}

      <!-- Projects -->
      ${projects && projects.length > 0 ? `
        <div class="section-title">Key Projects</div>
        ${projects.map(proj => `
          <div style="margin-bottom: 10px;">
            <div class="item-title">${proj.title} ${proj.subtitle ? `<span style="font-weight:normal; font-size:10pt;">(${proj.subtitle})</span>` : ''}</div>
            ${proj.technologies && proj.technologies.length > 0 ? `<div class="item-meta">Technologies: ${proj.technologies.join(', ')}</div>` : ''}
            ${proj.description ? `
              <ul>
                ${proj.description.split('\n').filter(Boolean).map(line => `
                  <li>${line.replace(/^[•\-\*]\s*/, '')}</li>
                `).join('')}
              </ul>
            ` : ''}
          </div>
        `).join('')}
      ` : ''}

      <!-- Skills -->
      ${(skills?.technical?.length || skills?.soft?.length || skills?.languages?.length) ? `
        <div class="section-title">Skills & Languages</div>
        ${skills?.technical?.length ? `<p><strong>Technical Skills:</strong> ${skills.technical.join(', ')}</p>` : ''}
        ${skills?.soft?.length ? `<p><strong>Soft Skills:</strong> ${skills.soft.join(', ')}</p>` : ''}
        ${skills?.languages?.length ? `<p><strong>Languages:</strong> ${skills.languages.map(l => `${l.language} (${l.proficiency})`).join(', ')}</p>` : ''}
      ` : ''}

      <!-- Certifications -->
      ${certifications && certifications.length > 0 ? `
        <div class="section-title">Certifications</div>
        <ul>
          ${certifications.map(c => `<li><strong>${c.title}</strong> — ${c.issuer} (${c.date})</li>`).join('')}
        </ul>
      ` : ''}

      <!-- Achievements -->
      ${achievements && achievements.length > 0 ? `
        <div class="section-title">Achievements & Honors</div>
        <ul>
          ${achievements.map(a => `<li><strong>${a.title}</strong> — ${a.organization} (${a.date}): ${a.description}</li>`).join('')}
        </ul>
      ` : ''}

      <!-- Interests -->
      ${interests && interests.length > 0 ? `
        <div class="section-title">Interests & Activities</div>
        <p>${interests.join(', ')}</p>
      ` : ''}

      <!-- References -->
      ${references && references.length > 0 ? `
        <div class="section-title">References</div>
        <ul>
          ${references.map(r => `<li><strong>${r.name}</strong> (${r.position} at ${r.company}) &nbsp;|&nbsp; ${r.email} &nbsp;|&nbsp; ${r.phone}</li>`).join('')}
        </ul>
      ` : ''}

      <!-- Custom Sections -->
      ${customSections && customSections.length > 0 ? customSections.map(sec => `
        <div class="section-title">${sec.title}</div>
        ${sec.items.map(item => `
          <div style="margin-bottom: 8px;">
            <div class="item-title">${item.title} ${item.subtitle ? `(${item.subtitle})` : ''}</div>
            ${item.date ? `<div class="item-meta">${item.date}</div>` : ''}
            ${item.description ? `<p style="margin: 2px 0;">${item.description}</p>` : ''}
          </div>
        `).join('')}
      `).join('') : ''}
    </body>
    </html>
  `;

  const blob = new Blob(['\ufeff', htmlContent], {
    type: 'application/msword;charset=utf-8',
  });
  const filename = `${(personalInfo.fullName || 'Resume').replace(/\s+/g, '_')}_Document.doc`;
  triggerBlobDownload(blob, filename);
  console.log(`[DocumentExporter] Microsoft Word document downloaded as "${filename}".`);
};

/**
 * Generates and downloads a JSON draft backup document.
 */
export const downloadAsJson = (data: ResumeData): void => {
  console.log('[DocumentExporter] Exporting JSON backup...', { title: data?.title });
  const jsonString = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
  const filename = `${(data.title || 'Resume').replace(/\s+/g, '_')}_Backup.json`;
  triggerBlobDownload(blob, filename);
  console.log(`[DocumentExporter] JSON backup downloaded as "${filename}".`);
};

/**
 * Cover Letter Exporters
 */
export const downloadCoverLetterAsTxt = (
  content: string,
  candidateName: string,
  companyName: string
): void => {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const filename = `${candidateName.replace(/\s+/g, '_')}_Cover_Letter_${companyName.replace(/\s+/g, '_')}.txt`;
  triggerBlobDownload(blob, filename);
};

export const downloadCoverLetterAsDoc = (
  content: string,
  candidateName: string,
  companyName: string
): void => {
  const htmlContent = `
    <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
    <head>
      <meta charset="utf-8">
      <title>Cover Letter - ${candidateName}</title>
      <style>
        body {
          font-family: Georgia, 'Times New Roman', serif;
          font-size: 11pt;
          line-height: 1.6;
          color: #1e293b;
          padding: 30px;
        }
        p {
          margin-bottom: 14px;
        }
      </style>
    </head>
    <body>
      ${content.split('\n').map(p => p.trim() ? `<p>${p}</p>` : '').join('')}
    </body>
    </html>
  `;
  const blob = new Blob(['\ufeff', htmlContent], {
    type: 'application/msword;charset=utf-8',
  });
  const filename = `${candidateName.replace(/\s+/g, '_')}_Cover_Letter_${companyName.replace(/\s+/g, '_')}.doc`;
  triggerBlobDownload(blob, filename);
};

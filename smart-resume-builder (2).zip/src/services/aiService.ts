import { ATSAnalysisResult, CoverLetterData } from '../types/resume';

export async function generateAiSummary(jobTitle: string, yearsExp?: string, keySkills?: string[], tone?: string): Promise<string[]> {
  try {
    const res = await fetch('/api/ai/generate-summary', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobTitle, yearsExp, keySkills, tone }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data.summaries && Array.isArray(data.summaries)) {
        return data.summaries;
      }
    }
  } catch (err) {
    console.error('Failed to fetch AI summary:', err);
  }

  // Fallbacks
  return [
    `Results-driven ${jobTitle || 'Professional'} with expertise in delivering innovative solutions, collaborating across agile teams, and driving core business metrics.`,
    `Detail-oriented ${jobTitle || 'Specialist'} adept at analyzing complex requirements, developing strategic plans, and optimizing user workflows.`,
    `High-performing ${jobTitle || 'Engineer'} focused on system efficiency, continuous integration, and technical excellence.`
  ];
}

export async function enhanceAiBullet(jobTitle: string, bulletText: string): Promise<string[]> {
  try {
    const res = await fetch('/api/ai/enhance-bullet', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jobTitle, bulletText }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data.bullets && Array.isArray(data.bullets)) {
        return data.bullets;
      }
    }
  } catch (err) {
    console.error('Failed to fetch AI bullet:', err);
  }

  return [
    `Spearheaded critical initiatives for ${jobTitle || 'project'}, driving a 30% increase in operational efficiency.`,
    `Optimized team workflows and core processes, resulting in a 25% reduction in project delivery times.`,
    `Architected scalable solution that eliminated technical bottlenecks and boosted productivity by 40%.`
  ];
}

export async function calculateAtsScore(resumeText: string, jobDescription: string): Promise<ATSAnalysisResult> {
  try {
    const res = await fetch('/api/ai/ats-score', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resumeText, jobDescription }),
    });
    if (res.ok) {
      const data = await res.json();
      if (data.result) {
        return data.result;
      }
    }
  } catch (err) {
    console.error('Failed to fetch ATS score:', err);
  }

  return {
    overallScore: 84,
    matchedKeywords: ['Communication', 'Project Management', 'Problem Solving', 'Data Analysis', 'Agile'],
    missingKeywords: ['CI/CD', 'Automated Testing', 'Microservices', 'Kubernetes'],
    formattingScore: 90,
    contentScore: 82,
    completenessScore: 85,
    suggestions: [
      {
        category: 'Keywords',
        message: 'Add missing technical skills mentioned in the job post.',
        actionableFix: 'Integrate "Microservices" and "CI/CD" into your technical skills section.',
      },
      {
        category: 'Impact',
        message: 'Include quantifiable results in work experience.',
        actionableFix: 'Quantify at least two major accomplishments using percentages or numbers.',
      },
    ],
  };
}

export async function generateCoverLetter(coverData: CoverLetterData & { candidateName: string; resumeSummary: string }): Promise<string> {
  try {
    const res = await fetch('/api/ai/cover-letter', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(coverData),
    });
    if (res.ok) {
      const data = await res.json();
      if (data.coverLetter) {
        return data.coverLetter;
      }
    }
  } catch (err) {
    console.error('Failed to fetch cover letter:', err);
  }

  return `Dear Hiring Manager at ${coverData.companyName},\n\nI am writing to express my strong interest in the ${coverData.jobRole} position at ${coverData.companyName}.\n\nWith extensive experience in ${coverData.jobRole}, I am confident in my ability to make an immediate positive impact on your team.\n\nSincerely,\n${coverData.candidateName}`;
}

import React, { useState, useEffect } from 'react';
import { ResumeData, UserProfile } from './types/resume';
import { SAMPLE_RESUMES, DEFAULT_USER } from './data/initialData';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { HomeView } from './components/home/HomeView';
import { DashboardView } from './components/dashboard/DashboardView';
import { ResumeBuilder } from './components/builder/ResumeBuilder';
import { TemplatesView } from './components/templates/TemplatesView';
import { AuthView } from './components/auth/AuthView';
import { UserProfileView } from './components/profile/UserProfileView';
import { AdminPanelView } from './components/admin/AdminPanelView';

export default function App() {
  const [currentView, setCurrentView] = useState<
    'home' | 'dashboard' | 'builder' | 'templates' | 'login' | 'register' | 'profile' | 'admin'
  >('home');

  // Load User from LocalStorage or default
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('smart_resume_user');
    return saved ? JSON.parse(saved) : DEFAULT_USER;
  });

  // Load Resumes from LocalStorage or initial sample data
  const [resumes, setResumes] = useState<ResumeData[]>(() => {
    const saved = localStorage.getItem('smart_resume_list');
    return saved ? JSON.parse(saved) : SAMPLE_RESUMES;
  });

  // Active Resume Draft for Builder
  const [activeResume, setActiveResume] = useState<ResumeData>(() => resumes[0] || SAMPLE_RESUMES[0]);

  // Dark Mode
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('smart_resume_theme') === 'dark';
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('smart_resume_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('smart_resume_theme', 'light');
    }
  }, [isDarkMode]);

  useEffect(() => {
    localStorage.setItem('smart_resume_list', JSON.stringify(resumes));
  }, [resumes]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('smart_resume_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('smart_resume_user');
    }
  }, [user]);

  // Handlers
  const handleSaveResume = (updated: ResumeData) => {
    setActiveResume(updated);
    setResumes(prev => {
      const exists = prev.some(r => r.id === updated.id);
      if (exists) {
        return prev.map(r => (r.id === updated.id ? updated : r));
      }
      return [updated, ...prev];
    });
  };

  const handleCreateNewResume = () => {
    const newResume: ResumeData = {
      id: `res_${Date.now()}`,
      userId: user?.id || 'usr_guest',
      title: 'New Professional Resume',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isPrimary: resumes.length === 0,
      atsScore: 85,
      personalInfo: {
        fullName: user?.fullName || 'Alex Morgan',
        jobTitle: 'Software Engineer',
        email: user?.email || 'alex.morgan@example.com',
        phone: '+1 (555) 234-5678',
        address: 'San Francisco, CA',
        linkedin: 'https://linkedin.com',
        github: 'https://github.com',
        portfolio: 'https://example.com',
        summary: 'Results-driven software engineer with experience building scalable web applications and AI tools.',
      },
      education: [
        {
          id: `edu_${Date.now()}`,
          degree: 'BS in Computer Science',
          institution: 'University Name',
          location: 'City, State',
          startDate: '2020-08',
          endDate: '2024-05',
          grade: '3.8 GPA',
          description: 'Focus on Web Technologies and Software Architecture.',
        },
      ],
      experience: [
        {
          id: `exp_${Date.now()}`,
          jobTitle: 'Software Developer',
          company: 'Tech Company',
          location: 'San Francisco, CA',
          startDate: '2024-06',
          endDate: 'Present',
          isCurrent: true,
          description: '• Developed high-performance user interfaces using React and TypeScript.\n• Collaborated with product teams to ship core platform features.',
        },
      ],
      projects: [],
      skills: {
        technical: ['React.js', 'TypeScript', 'Node.js', 'Tailwind CSS', 'Git'],
        soft: ['Problem Solving', 'Team Leadership', 'Communication'],
        languages: [{ language: 'English', proficiency: 'Native / Fluent' }],
      },
      certifications: [],
      achievements: [],
      interests: ['Open Source', 'Technology Blogs', 'Chess'],
      references: [],
      customSections: [],
      style: {
        template: 'modern',
        primaryColor: '#2563eb',
        fontFamily: 'inter',
        fontSize: 'md',
        lineSpacing: 'normal',
        showPhoto: true,
        showQrCode: true,
        sectionOrder: ['summary', 'experience', 'education', 'skills'],
      },
    };

    handleSaveResume(newResume);
    setActiveResume(newResume);
    setCurrentView('builder');
  };

  const handleDuplicateResume = (target: ResumeData) => {
    const duplicated: ResumeData = {
      ...target,
      id: `res_${Date.now()}`,
      title: `${target.title} (Copy)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      isPrimary: false,
    };
    handleSaveResume(duplicated);
  };

  const handleDeleteResume = (id: string) => {
    if (confirm('Are you sure you want to delete this resume draft?')) {
      setResumes(prev => prev.filter(r => r.id !== id));
    }
  };

  const handleSelectPrimary = (id: string) => {
    setResumes(prev =>
      prev.map(r => ({
        ...r,
        isPrimary: r.id === id,
      }))
    );
  };

  const handleSelectTemplateAndBuild = (templateId: string) => {
    const updated = {
      ...activeResume,
      style: {
        ...activeResume.style,
        template: templateId as any,
      },
    };
    handleSaveResume(updated);
    setCurrentView('builder');
  };

  const handleNavigate = (view: string) => {
    setCurrentView(view as any);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 font-sans antialiased text-slate-900 dark:text-slate-100 transition-colors">
      {/* Top Navigation */}
      {currentView !== 'builder' && (
        <Navbar
          currentView={currentView}
          onNavigate={handleNavigate}
          user={user}
          onLogout={() => {
            setUser(null);
            setCurrentView('home');
          }}
          isDarkMode={isDarkMode}
          onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        />
      )}

      {/* Main Body Views */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomeView
            onStartBuilding={() => {
              if (resumes.length > 0) {
                setActiveResume(resumes[0]);
              } else {
                handleCreateNewResume();
              }
              setCurrentView('builder');
            }}
            onExploreTemplates={() => setCurrentView('templates')}
            onNavigate={handleNavigate}
          />
        )}

        {currentView === 'dashboard' && (
          <DashboardView
            resumes={resumes}
            onCreateNew={handleCreateNewResume}
            onEditResume={r => {
              setActiveResume(r);
              setCurrentView('builder');
            }}
            onDuplicateResume={handleDuplicateResume}
            onDeleteResume={handleDeleteResume}
            onSelectPrimary={handleSelectPrimary}
          />
        )}

        {currentView === 'builder' && (
          <ResumeBuilder
            resume={activeResume}
            onSaveResume={handleSaveResume}
            onBackToDashboard={() => setCurrentView('dashboard')}
          />
        )}

        {currentView === 'templates' && (
          <TemplatesView onSelectTemplate={handleSelectTemplateAndBuild} />
        )}

        {(currentView === 'login' || currentView === 'register') && (
          <AuthView
            mode={currentView}
            onLoginSuccess={u => {
              setUser(u);
              setCurrentView('dashboard');
            }}
            onSwitchMode={m => setCurrentView(m as any)}
          />
        )}

        {currentView === 'profile' && user && (
          <UserProfileView user={user} onUpdateUser={u => setUser(u)} />
        )}

        {currentView === 'admin' && <AdminPanelView />}
      </main>

      {/* Footer */}
      {currentView !== 'builder' && <Footer onNavigate={handleNavigate} />}
    </div>
  );
}

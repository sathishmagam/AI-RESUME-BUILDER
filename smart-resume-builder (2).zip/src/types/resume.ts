export type TemplateId = 'classic' | 'modern' | 'executive' | 'minimal' | 'creative' | 'tech';

export type FontStyle = 'inter' | 'serif' | 'mono' | 'display';

export interface PersonalInfo {
  fullName: string;
  jobTitle: string;
  email: string;
  phone: string;
  address: string;
  linkedin: string;
  github: string;
  portfolio: string;
  photoUrl?: string;
  summary: string;
}

export interface Education {
  id: string;
  degree: string;
  institution: string;
  location: string;
  startDate: string;
  endDate: string;
  grade: string;
  description: string;
}

export interface WorkExperience {
  id: string;
  jobTitle: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
  description: string; // Markdown or line-separated bullet points
}

export interface Project {
  id: string;
  title: string;
  subtitle?: string;
  technologies: string[];
  githubUrl?: string;
  liveUrl?: string;
  startDate?: string;
  endDate?: string;
  description: string;
}

export interface SkillCategory {
  category: string; // e.g. "Frontend", "Backend", "Tools", "Soft Skills"
  skills: string[];
}

export interface Certification {
  id: string;
  title: string;
  issuer: string;
  date: string;
  credentialId?: string;
  url?: string;
}

export interface Achievement {
  id: string;
  title: string;
  organization: string;
  date: string;
  description: string;
}

export interface Reference {
  id: string;
  name: string;
  position: string;
  company: string;
  email: string;
  phone: string;
}

export interface CustomSectionItem {
  id: string;
  title: string;
  subtitle?: string;
  date?: string;
  description: string;
}

export interface CustomSection {
  id: string;
  title: string;
  items: CustomSectionItem[];
}

export interface ResumeStyleConfig {
  template: TemplateId;
  primaryColor: string;
  fontFamily: FontStyle;
  fontSize: 'sm' | 'md' | 'lg';
  lineSpacing: 'compact' | 'normal' | 'relaxed';
  showPhoto: boolean;
  showQrCode: boolean;
  sectionOrder: string[]; // array of section keys for reordering
}

export interface ResumeData {
  id: string;
  userId: string;
  title: string; // e.g., "Software Engineer 2026"
  createdAt: string;
  updatedAt: string;
  isPrimary?: boolean;
  atsScore?: number;
  personalInfo: PersonalInfo;
  education: Education[];
  experience: WorkExperience[];
  projects: Project[];
  skills: {
    technical: string[];
    soft: string[];
    languages: { language: string; proficiency: string }[];
  };
  certifications: Certification[];
  achievements: Achievement[];
  interests: string[];
  references: Reference[];
  customSections: CustomSection[];
  style: ResumeStyleConfig;
}

export interface UserProfile {
  id: string;
  fullName: string;
  email: string;
  phone?: string;
  role: 'user' | 'admin';
  profilePhoto?: string;
  joinedDate: string;
  targetRole?: string;
}

export interface ATSAnalysisResult {
  overallScore: number; // 0 - 100
  matchedKeywords: string[];
  missingKeywords: string[];
  formattingScore: number;
  contentScore: number;
  completenessScore: number;
  suggestions: {
    category: 'Keywords' | 'Formatting' | 'Impact' | 'Length';
    message: string;
    actionableFix: string;
  }[];
}

export interface CoverLetterData {
  companyName: string;
  jobRole: string;
  jobDescription: string;
  tone: 'professional' | 'enthusiastic' | 'confident' | 'creative';
  generatedContent?: string;
}
